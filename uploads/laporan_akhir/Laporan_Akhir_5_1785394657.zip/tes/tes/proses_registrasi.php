<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        body { font-family: 'Poppins', sans-serif; background: #f4f7fe; }
    </style>
</head>
<body>

<?php
include 'koneksi.php';

$nama = mysqli_real_escape_string($koneksi, $_POST['nama_lengkap']);
$user = mysqli_real_escape_string($koneksi, $_POST['username']);
$pass = mysqli_real_escape_string($koneksi, $_POST['password']);

// 1. Cek apakah username/NIS sudah terdaftar
$cek = mysqli_query($koneksi, "SELECT * FROM tbl_user WHERE username='$user'");

if(mysqli_num_rows($cek) > 0) {
    echo "<script>
        Swal.fire({
            icon: 'error',
            title: 'Waduh...',
            text: 'NIS atau Username ini sudah terdaftar!',
            confirmButtonColor: '#e74c3c'
        }).then(function() {
            window.location = 'registrasi.php';
        });
    </script>";
} else {
    // 2. Insert ke tbl_user
    $insert_user = mysqli_query($koneksi, "INSERT INTO tbl_user (nama_lengkap, username, password, role) 
                                           VALUES ('$nama', '$user', '$pass', 'user')");

    if($insert_user) {
        // 3. Insert ke tbl_anggota
        $insert_agt = mysqli_query($koneksi, "INSERT INTO tbl_anggota (nis, nama_lengkap) 
                                              VALUES ('$user', '$nama')");
        
        if($insert_agt) {
            echo "<script>
                Swal.fire({
                    icon: 'success',
                    title: 'Berhasil Daftar!',
                    text: 'Akun kamu sudah aktif, silakan login.',
                    showConfirmButton: false,
                    timer: 3000,
                    timerProgressBar: true
                }).then(function() {
                    window.location = 'index.php';
                });
            </script>";
        } else {
            echo "Error Database Anggota: " . mysqli_error($koneksi);
        }
    } else {
        echo "Error Database User: " . mysqli_error($koneksi);
    }
}
?>
</body>
</html>