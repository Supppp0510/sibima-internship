<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Perpustakaan Litera-Z</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        /* RESET & BASE */
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
             font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            /* Efek Kertas Bergaris */
            background-color: #f9f9f9; 
            background-image: linear-gradient(#e0e0e0 1px, transparent 1px); 
            background-size: 100% 30px; 
            
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            padding: 20px; 
            position: relative;
            overflow: hidden; /* Mencegah scroll jika ikon keluar batas */
        }

        .decor-icon {
            position: fixed;
            color: #6ea2e2; /* Warna abu-abu terang */
            opacity: 0.35; /* Transparansi ikon */
            z-index: -1;
            pointer-events: none; /* Agar ikon tidak mengganggu saat diklik */
        }
        
        /* Posisi dan Rotasi Ikon Agar Tersebar */
        .icon-1 { top: 5%; left: 5%; font-size: 80px; transform: rotate(-25deg); }
        .icon-2 { top: 40%; left: 3%; font-size: 100px; transform: rotate(15deg); }
        .icon-3 { bottom: 8%; left: 8%; font-size: 120px; transform: rotate(-10deg); }
        .icon-4 { top: 8%; right: 8%; font-size: 110px; transform: rotate(20deg); }
        .icon-5 { top: 45%; right: 4%; font-size: 90px; transform: rotate(-15deg); }
        .icon-6 { bottom: 10%; right: 10%; font-size: 130px; transform: rotate(10deg); }
        .icon-7 { top: -20px; left: 45%; font-size: 100px; transform: rotate(45deg); opacity: 0.2; }
        .icon-8 { bottom: -20px; left: 40%; font-size: 110px; transform: rotate(-30deg); opacity: 0.2; }

        /* BUNGKUS UTAMA: KARTU MELAYANG */
        .login-card {
            background: #ffffff;
            width: 100%;
            max-width: 950px; 
            min-height: 550px;
            border-radius: 24px; 
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.08); 
            display: flex;
            padding: 15px; 
        }

        /* PANEL KIRI (VISUAL) */
        .panel-left {
            width: 45%;
            background: linear-gradient(135deg, #4facfe 0%, #6c5ce7 50%, #a29bfe 100%);
            border-radius: 20px; 
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            padding: 50px 40px;
            color: white;
        }
        .panel-left .icon-logo { font-size: 2.8rem; }
        .panel-left-text-group .left-panel-title { font-size: 2.2rem; font-weight: 700; line-height: 1.3; }
        .panel-left-text-group p { font-size: 1.05rem; margin-bottom: 10px; opacity: 0.9; }

        /* PANEL KANAN (AREA FORM) */
        .panel-right {
            width: 55%;
            display: flex;
            flex-direction: column;
            justify-content: center;
            padding: 40px 60px;
        }

        /* WRAPPER FORM AGAR TETAP RAPI */
        .form-wrapper {
            max-width: 420px; 
            width: 100%;
            margin: 0 auto; 
        }

        /* PENGATURAN LOGO GAMBAR LITERA-Z */
        .right-panel-logo { margin-bottom: 20px; display: block; }
        .right-panel-logo img { height: 85px; width: auto; object-fit: contain; }

        .panel-right-title { font-size: 2rem; color: #1a202c; margin-bottom: 10px; }
        .panel-right-subtitle { color: #718096; font-size: 0.95rem; line-height: 1.5; margin-bottom: 25px; }
        
        /* ALERT NOTIFIKASI */
        .alert { padding: 12px; border-radius: 8px; margin-bottom: 20px; font-size: 0.9rem; text-align: center; font-weight: 500; }
        .alert-danger { background-color: #fee2e2; color: #b91c1c; border: 1px solid #fca5a5; }
        .alert-success { background-color: #dcfce7; color: #15803d; border: 1px solid #86efac; }
        .alert-warning { background-color: #fef08a; color: #a16207; border: 1px solid #fde047; }

        /* INPUT STYLES */
        .input-group { margin-bottom: 20px; }
        .input-group label { display: block; font-size: 0.9rem; font-weight: 600; color: #2d3748; margin-bottom: 8px; }
        .input-group input { width: 100%; padding: 14px 18px; border: 1px solid #e2e8f0; border-radius: 8px; font-size: 0.95rem; color: #2d3748; background-color: #f8fafc; transition: all 0.3s; }
        .input-group input:focus { outline: none; border-color: #6c5ce7; background-color: #fff; box-shadow: 0 0 0 3px rgba(108, 92, 231, 0.1); }
        .password-input { position: relative; }
        .password-input i { position: absolute; right: 15px; top: 50%; transform: translateY(-50%); color: #a0aec0; cursor: pointer; }
        
        /* TOMBOL & LAINNYA */
        .btn-login { width: 100%; padding: 15px; background-color: #5a4fcf; color: white; border: none; border-radius: 8px; font-size: 1rem; font-weight: 600; cursor: pointer; margin-top: 10px; transition: 0.3s; }
        .btn-login:hover { background-color: #4b41b5; }
        .bottom-text { text-align: center; font-size: 0.9rem; color: #718096; margin-top: 30px; }
        .bottom-text a { color: #5a4fcf; text-decoration: none; font-weight: 600; }

        /* RESPONSIVITAS HP */
        @media (max-width: 768px) {
            .login-card { flex-direction: column; padding: 0; min-height: auto; }
            .panel-left { display: none; }
            .panel-right { width: 100%; padding: 40px 20px; }
        }
    </style>
</head>
<body>

    <i class="fas fa-pen decor-icon icon-1"></i>
    <i class="fas fa-book-open decor-icon icon-2"></i>
    <i class="fas fa-paperclip decor-icon icon-3"></i>
    <i class="fas fa-graduation-cap decor-icon icon-4"></i>
    <i class="fas fa-paperclip decor-icon icon-5"></i>
    <i class="fas fa-book decor-icon icon-6"></i>
    <i class="fas fa-graduation-cap decor-icon icon-7"></i>
    <i class="fas fa-pen decor-icon icon-8"></i>

    <div class="login-card">
        
        <div class="panel-left">
            <div class="icon-logo"><i class="fas fa-book-open"></i></div>
            <div class="panel-left-text-group">
                <p>Akses mudah dan cepat</p>
                <h2 class="left-panel-title">Masuk ke pusat personalmu untuk membaca dan belajar</h2>
            </div>
        </div>

        <div class="panel-right">
            <div class="form-wrapper">
                
                <div class="right-panel-logo">
                    <img src="img/litera-z.png" alt="litera-z">
                </div>

                <h2 class="panel-right-title">Masuk ke Akun</h2>
                <p class="panel-right-subtitle">Akses tugas, catatan, dan buku kapan saja, di mana saja — kelola semuanya dalam satu tempat.</p>

                <?php 
                if(isset($_GET['pesan'])){
                    if($_GET['pesan'] == "gagal"){
                        echo "<div class='alert alert-danger'>Username atau Password salah!</div>";
                    } else if($_GET['pesan'] == "logout"){
                        echo "<div class='alert alert-success'>Anda telah berhasil logout.</div>";
                    } else if($_GET['pesan'] == "belum_login"){
                        echo "<div class='alert alert-warning'>Anda harus login terlebih dahulu.</div>";
                    } else if($_GET['pesan'] == "akses_ditolak"){
                        echo "<div class='alert alert-danger'>Akses ditolak! Pastikan Anda memiliki hak akses.</div>";
                    }
                }
                ?>

                <form action="cek_login.php" method="POST">
                    <div class="input-group">
                        <label>Email atau Username</label>
                        <input type="text" name="username" placeholder="masukkan email/username" required>
                    </div>

                    <div class="input-group">
                        <label>Password</label>
                        <div class="password-input">
                            <input type="password" id="password" name="password" placeholder="••••••••••" required>
                            <i class="fas fa-eye" id="togglePassword"></i>
                        </div>
                    </div>

                    <button type="submit" class="btn-login">Login Sekarang</button>

                    <p class="bottom-text">Belum punya akun? <a href="registrasi.php">Daftar</a></p>
                </form>
            </div>
        </div>
        
    </div>

    <script>
        const togglePassword = document.querySelector('#togglePassword');
        const password = document.querySelector('#password');
        togglePassword.addEventListener('click', function () {
            const type = password.getAttribute('type') === 'password' ? 'text' : 'password';
            password.setAttribute('type', type);
            this.classList.toggle('fa-eye-slash');
        });
    </script>
</body>
</html>