<?php
session_start();
// 1. Jalur koneksi naik satu tingkat
include '../koneksi.php';

// 2. Proteksi Halaman: Cek login dan role admin
if (!isset($_SESSION['status']) || $_SESSION['status'] != "login" || $_SESSION['role'] != "admin") {
    header("location:../index.php?pesan=belum_login");
    exit();
}

// ==========================================
// 3. LOGIKA PROSES TAMBAH DATA ANGGOTA & USER
// ==========================================
if (isset($_POST['simpan'])) {
    $nama     = mysqli_real_escape_string($koneksi, $_POST['nama_lengkap']);
    $jk       = mysqli_real_escape_string($koneksi, $_POST['jk']);
    $username = mysqli_real_escape_string($koneksi, $_POST['username']); 
    $no_hp    = mysqli_real_escape_string($koneksi, $_POST['no_hp']);
    $alamat   = mysqli_real_escape_string($koneksi, $_POST['alamat']);
    $pass     = mysqli_real_escape_string($koneksi, $_POST['password']); 

    $cek = mysqli_query($koneksi, "SELECT * FROM tbl_user WHERE username = '$username'");
    if(mysqli_num_rows($cek) > 0){
        echo "<script>
            document.addEventListener('DOMContentLoaded', function() {
                Swal.fire({
                    title: 'Peringatan!',
                    text: 'Username Sudah Terdaftar!',
                    icon: 'warning',
                    confirmButtonColor: '#f39c12'
                });
            });
        </script>";
    } else {
        // Simpan ke tbl_user (Untuk Login)
        $simpan_user = mysqli_query($koneksi, "INSERT INTO tbl_user (username, password, nama_lengkap, role) VALUES ('$username', '$pass', '$nama', 'user')");
        
        // Simpan ke tbl_anggota 
        $simpan_anggota = mysqli_query($koneksi, "INSERT INTO tbl_anggota (nama_lengkap, jk, username, no_hp, alamat, password, password_awal, foto) VALUES ('$nama', '$jk', '$username', '$no_hp', '$alamat', '$pass', '$pass', 'user.png')");
        
        if ($simpan_user && $simpan_anggota) {
            echo "<script>
                document.addEventListener('DOMContentLoaded', function() {
                    Swal.fire({
                        title: 'Berhasil!',
                        text: 'Anggota Berhasil Dibuat!',
                        icon: 'success',
                        confirmButtonColor: '#667eea'
                    }).then((result) => {
                        window.location.href = 'anggota.php';
                    });
                });
            </script>";
        }
    }
}

// ==========================================
// 4. LOGIKA PROSES HAPUS DATA DI KEDUA TABEL
// ==========================================
if (isset($_GET['aksi']) && $_GET['aksi'] == 'hapus') {
    $id       = mysqli_real_escape_string($koneksi, $_GET['id']);
    $username = mysqli_real_escape_string($koneksi, $_GET['username']);
    
    $hapus_anggota = mysqli_query($koneksi, "DELETE FROM tbl_anggota WHERE id_anggota='$id'");
    $hapus_user    = mysqli_query($koneksi, "DELETE FROM tbl_user WHERE username='$username'");
    
    if ($hapus_anggota && $hapus_user) {
        echo "<script>
            document.addEventListener('DOMContentLoaded', function() {
                Swal.fire({
                    title: 'Dihapus!',
                    text: 'Data Anggota & Akun Berhasil Dihapus!',
                    icon: 'success',
                    confirmButtonColor: '#667eea'
                }).then((result) => {
                    window.location.href = 'anggota.php';
                });
            });
        </script>";
    }
}

// ==========================================
// 5. LOGIKA PROSES RESET PASSWORD USER
// ==========================================
if (isset($_GET['aksi']) && $_GET['aksi'] == 'reset') {
    $id = mysqli_real_escape_string($koneksi, $_GET['id']);

    $cek_data = mysqli_query($koneksi, "SELECT username, password_awal FROM tbl_anggota WHERE id_anggota = '$id'");
    $data_anggota = mysqli_fetch_array($cek_data);
    
    $username = $data_anggota['username'];
    $password_bawaan = $data_anggota['password_awal'];

    if ($password_bawaan) {
        $update_anggota = mysqli_query($koneksi, "UPDATE tbl_anggota SET password = '$password_bawaan' WHERE id_anggota = '$id'");
        $update_user    = mysqli_query($koneksi, "UPDATE tbl_user SET password = '$password_bawaan' WHERE username = '$username'");

        if ($update_anggota && $update_user) {
            echo "<script>
                document.addEventListener('DOMContentLoaded', function() {
                    Swal.fire({
                        title: 'Reset Berhasil!',
                        html: 'Password berhasil direset!<br><br><b>Username:</b> $username<br><b>Password Baru:</b> $password_bawaan',
                        icon: 'success',
                        confirmButtonColor: '#3498db'
                    }).then((result) => {
                        window.location.href = 'anggota.php';
                    });
                });
            </script>";
        }
    } else {
        echo "<script>
            document.addEventListener('DOMContentLoaded', function() {
                Swal.fire({
                    title: 'Gagal!',
                    text: 'Gagal! Data password awal tidak ditemukan.',
                    icon: 'error',
                    confirmButtonColor: '#e74c3c'
                }).then((result) => {
                    window.location.href = 'anggota.php';
                });
            });
        </script>";
    }
}

// ==========================================
// 6. LOGIKA PROSES SIMPAN EDIT DATA (UPDATE)
// ==========================================
if (isset($_POST['update'])) {
    $id_anggota    = $_POST['id_anggota'];
    $username_lama = $_POST['username_lama'];
    $nama          = mysqli_real_escape_string($koneksi, $_POST['nama_lengkap']);
    $jk            = mysqli_real_escape_string($koneksi, $_POST['jk']);
    $username_baru = mysqli_real_escape_string($koneksi, $_POST['username']);
    $no_hp         = mysqli_real_escape_string($koneksi, $_POST['no_hp']);
    $alamat        = mysqli_real_escape_string($koneksi, $_POST['alamat']);

    $query_anggota = "UPDATE tbl_anggota SET nama_lengkap='$nama', jk='$jk', username='$username_baru', no_hp='$no_hp', alamat='$alamat' WHERE id_anggota='$id_anggota'";
    $query_user    = "UPDATE tbl_user SET username='$username_baru', nama_lengkap='$nama' WHERE username='$username_lama'";

    $update_anggota = mysqli_query($koneksi, $query_anggota);
    $update_user    = mysqli_query($koneksi, $query_user);

    if ($update_anggota && $update_user) {
        echo "<script>
            document.addEventListener('DOMContentLoaded', function() {
                Swal.fire({
                    title: 'Diperbarui!',
                    text: 'Data Anggota Berhasil Diperbarui!',
                    icon: 'success',
                    confirmButtonColor: '#667eea'
                }).then((result) => {
                    window.location.href = 'anggota.php';
                });
            });
        </script>";
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Anggota - Admin Litera-Z</title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css">
    
    <style>
        .btn-aksi { 
            padding: 5px 10px; 
            color: white; 
            text-decoration: none; 
            border-radius: 4px; 
            font-size: 0.75rem; 
            margin-right: 5px; 
            display: inline-block; 
        }
        
        /* INI KODE UNTUK MENGUBAH KEPALA TABEL MENJADI UNGU-BIRU */
        table.dataTable thead th {
            background: linear-gradient(135deg, #4e54c8 0%, #8f94fb 100%) !important;
            color: white !important;
            font-weight: 600;
            border-bottom: 2px solid rgba(255,255,255,0.2) !important;
            padding: 12px !important;
        }

        table.dataTable tbody td {
            padding: 12px !important;
            border-bottom: 1px solid #eee !important;
            font-size: 0.9rem;
        }

        /* --- KODE BARU UNTUK MERAPIKAN BAGIAN BAWAH TABEL --- */
        .dataTables_wrapper .bottom {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 15px;
        }

        .dataTables_wrapper .dataTables_info,
        .dataTables_wrapper .dataTables_length,
        .dataTables_wrapper .dataTables_paginate {
            margin: 0 !important;
            padding: 0 !important;
        }
    </style>
</head>
<body>
    <div class="dashboard-container">
        <aside class="sidebar">
            <div class="sidebar-header">
                <img src="../img/logo1.png" alt="Logo Litera-Z" class="sidebar-logo">
            </div>
            <ul class="sidebar-menu">
                <li><a href="index.php">Dashboard</a></li>
                <li><a href="buku.php">Data Buku</a></li>
                <li><a href="rak.php">Rak Buku</a></li>
                <li><a href="anggota.php" class="active">Data Anggota</a></li>
                <li><a href="transaksi.php">Peminjaman</a></li>
                <li><a href="laporan.php">Laporan</a></li>
                <li><a href="pengaturan.php">Pengaturan</a></li>
            <li style="margin-top: 15px; border-top: 1px solid rgba(255,255,255,0.1); padding-top: 10px;">
        <a href="../logout.php" onclick="return confirm('Apakah anda yakin ingin keluar?')" style="color: #ff7675; font-weight: bold;">Logout</a>
    </li>
</ul>
            </ul>
        </aside>

        <main class="main-content">
            <div class="content-header">
                <h1>Data Anggota</h1>
            </div>

            <div class="content-box">
                <h2 style="margin-bottom: 1rem;">Daftar Anggota</h2>
                <button type="button" id="btnToggleTambah" onclick="toggleFormTambah()" style="background: #667eea; color: white; border: none; padding: 8px 16px; border-radius: 5px; cursor: pointer; font-weight: bold; font-family: inherit; font-size: 13px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); margin-bottom: 15px;">
                    + Tambah Anggota 
                </button>
                
                <table id="tabelAnggota" class="display" style="width:100%">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Nama</th>
                            <th>Jenis Kelamin</th> 
                            <th>Username</th>
                            <th>No. HP</th> 
                            <th>Alamat</th> 
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                <?php
                $no = 1;
                $query = "SELECT * FROM tbl_anggota ORDER BY id_anggota DESC";
                $tampil = mysqli_query($koneksi, $query);
                while($data = mysqli_fetch_array($tampil)){?>
                <tr>
                    <td><?php echo $no++; ?></td>
                    <td><?php echo $data['nama_lengkap']; ?></td>
                    <td>
                    <?php 
                    if($data['jk'] == 'L') {echo "Laki-laki";} elseif($data['jk'] == 'P') {echo "Perempuan";} else {echo "-"; }
                    ?></td>
                    <td><b style="color: #4e54c8;"><?php echo $data['username']; ?></b></td>
                    <td><?php echo $data['no_hp']; ?></td>
                    <td><?php echo $data['alamat']; ?></td>
                    <td>
                        <button type="button" class="btn-aksi" style="background:#f39c12; border:none; cursor:pointer; font-family:inherit;" 
                        data-toggle="modal" data-target="#editModal<?php echo $data['id_anggota']; ?>"> Edit </button>       
                        
                        <a href="#" class="btn-aksi" 
                        style="background:#e74c3c;"
                        onclick="konfirmasiHapus('anggota.php?aksi=hapus&id=<?php echo $data['id_anggota']; ?>&username=<?php echo $data['username']; ?>')">Hapus</a>
                        
                        <div class="modal fade" id="editModal<?php echo $data['id_anggota']; ?>" tabindex="-1" role="dialog" aria-hidden="true" style="display: none; padding-right: 0px;">
                            <div class="modal-dialog modal-md modal-dialog-centered" role="document" style="display: flex; align-items: center; justify-content: center; min-height: calc(100% - 3.5rem); margin: 1.75rem auto;">
                                <div class="modal-content" style="border-radius: 12px; color: #333; text-align: left; box-shadow: 0 5px 15px rgba(0,0,0,0.2); overflow: hidden;">
                                    
                                    <div class="modal-header" style="background: #667eea; color: white; padding: 15px; border-bottom: none;">
                                        <h5 class="modal-title" style="margin:0; font-family: inherit; font-weight: bold;">Edit Data Anggota</h5>
                                    </div>
                                    
                                    <form action="" method="POST">
                                        <div class="modal-body" style="padding: 25px 20px 20px 20px;">
                                            
                                            <div style="text-align: center; margin-bottom: 25px;">
                                                <img src="../img/user.png" alt="Foto Profil" style="width: 100px; height: 100px; border-radius: 50%; object-fit: cover; border: 3px solid #667eea; box-shadow: 0 3px 6px rgba(0,0,0,0.16);">
                                                <p style="margin: 8px 0 0 0; font-size: 12px; color: #666; font-weight: bold; font-family: inherit;">Foto Profil</p>
                                            </div>
                                            <input type="hidden" name="id_anggota" value="<?php echo $data['id_anggota']; ?>">
                                            <input type="hidden" name="username_lama" value="<?php echo $data['username']; ?>">
                                            
                                            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin-bottom: 15px;">
                                                <div>
                                                    <label style="display:block; margin-bottom:5px; font-weight:bold; font-size:13px;">Nama Lengkap</label>
                                                    <input type="text" name="nama_lengkap" value="<?php echo $data['nama_lengkap']; ?>" required style="width:100%; padding:10px; border:1px solid #ddd; border-radius:5px; box-sizing: border-box;">
                                                </div>
                                                <div>
                                                    <label style="display:block; margin-bottom:5px; font-weight:bold; font-size:13px;">Jenis Kelamin</label>
                                                    <select name="jk" required style="width:100%; padding:10px; border:1px solid #ddd; border-radius:5px; box-sizing: border-box;">
                                                        <option value="L" <?php if($data['jk'] == 'L') echo 'selected'; ?>>Laki-laki</option>
                                                        <option value="P" <?php if($data['jk'] == 'P') echo 'selected'; ?>>Perempuan</option>
                                                    </select>
                                                </div>
                                            </div>
                                            
                                            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin-bottom: 15px;">
                                                <div>
                                                    <label style="display:block; margin-bottom:5px; font-weight:bold; font-size:13px;">Username (NIS)</label>
                                                    <input type="text" name="username" value="<?php echo $data['username']; ?>" required style="width:100%; padding:10px; border:1px solid #ddd; border-radius:5px; box-sizing: border-box;">
                                                </div>
                                                <div>
                                                    <label style="display:block; margin-bottom:5px; font-weight:bold; font-size:13px;">No. WhatsApp</label>
                                                    <input type="text" name="no_hp" value="<?php echo $data['no_hp']; ?>" required style="width:100%; padding:10px; border:1px solid #ddd; border-radius:5px; box-sizing: border-box;">
                                                </div>
                                            </div>
                                            
                                            <div style="margin-bottom: 15px;">
                                                <label style="display:block; margin-bottom:5px; font-weight:bold; font-size:13px;">Alamat</label>
                                                <input type="text" name="alamat" value="<?php echo $data['alamat']; ?>" required style="width:100%; padding:10px; border:1px solid #ddd; border-radius:5px; box-sizing: border-box;">
                                            </div>
                                            
                                            <div style="margin-top: 25px; padding: 15px; background: #fff2e6; border: 1px dashed #ff9933; border-radius: 5px;">
                                                <p style="margin: 0 0 10px 0; font-size: 13px; color: #e67e22; font-weight: bold;">Zona Keamanan & Akun:</p>
                                                <a href="anggota.php?aksi=reset&id=<?php echo $data['id_anggota']; ?>" class="btn-aksi" style="background:#3498db;" onclick="return confirm('Reset password menjadi password awal?')">Reset Password</a>
                                            </div>
                                        </div>
                                        
                                        <div class="modal-footer" style="padding: 15px; border-top: 1px solid #eee; text-align: right; background: #fbfbfb;">
                                            <button type="button" class="btn btn-secondary" data-dismiss="modal" style="background:#95a5a6; color:white; border:none; padding:8px 15px; border-radius:5px; cursor:pointer; font-size:13px;">Batal</button>
                                            <button type="submit" name="update" class="btn btn-primary" style="background:#f1c40f; color:white; border:none; padding:8px 15px; border-radius:5px; cursor:pointer; font-size:13px; font-weight:bold; margin-left:5px;">Simpan Perubahan</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </td>
                </tr>
                <?php } ?>
                    </tbody>
                </table>
            </div>
        </main>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>

    <script>
        $(document).ready( function () {
            $('#tabelAnggota').DataTable({
                "language": { "url": "//cdn.datatables.net/plug-ins/1.13.4/i18n/id.json" },
                "dom": '<"top"f>rt<"bottom"ilp><"clear">'
            });
        });

        function konfirmasiHapus(url) {
            Swal.fire({
                title: 'Hapus Anggota?',
                text: "Data anggota dan akun login akan dihapus permanen!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#e74c3c',
                cancelButtonColor: '#6c757d',
                confirmButtonText: 'Ya, Hapus',
                cancelButtonText: 'Batal'
            }).then((result) => {
                if (result.isConfirmed) { window.location.href = url; }
            });
        }
    </script>
</body>
</html>