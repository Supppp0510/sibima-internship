<?php
session_start();
// 1. Jalur koneksi naik satu tingkat ke luar folder admin
include '../koneksi.php';

// 2. Proteksi Halaman: Cek login dan role admin
if (!isset($_SESSION['status']) || $_SESSION['status'] != "login" || $_SESSION['role'] != "admin") {
    header("location:../index.php?pesan=belum_login");
    exit();
}

// 3. HITUNG DATA UNTUK LAPORAN (Perbaikan nama kolom dari status_pinjam menjadi status)
// Hitung Total Buku
$q_buku = mysqli_query($koneksi, "SELECT COUNT(*) as total FROM tbl_buku");
$d_buku = mysqli_fetch_assoc($q_buku);

// Hitung Total Anggota
$q_agt = mysqli_query($koneksi, "SELECT COUNT(*) as total FROM tbl_anggota");
$d_agt = mysqli_fetch_assoc($q_agt);

// Hitung Buku Dipinjam
$q_pinjam = mysqli_query($koneksi, "SELECT COUNT(*) as total FROM tbl_transaksi WHERE status='Dipinjam'");
$d_pinjam = mysqli_fetch_assoc($q_pinjam);

// Hitung Buku Dikembalikan
$q_kembali = mysqli_query($koneksi, "SELECT COUNT(*) as total FROM tbl_transaksi WHERE status='Dikembalikan'");
$d_kembali = mysqli_fetch_assoc($q_kembali);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laporan - Admin Litera-Z</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <div class="dashboard-container">
        <aside class="sidebar">
            <div class="sidebar-header">
                <img src="../img/logo1.png" alt="Logo Litera-Z" class="sidebar-logo">
            </div>
            <ul class="sidebar-menu">
                <li><a href="index.php">Dashboard</a></li>
                <li><a href="buku.php">Data Buku</a></li>
                <li><a href="rak.php">Rak Buku</a></li>
                <li><a href="anggota.php">Data Anggota</a></li>
                <li><a href="transaksi.php">Peminjaman</a></li>
                <li><a href="laporan.php" class="active">Laporan</a></li>
                <li><a href="pengaturan.php">Pengaturan</a></li>
            <li style="margin-top: 15px; border-top: 1px solid rgba(255,255,255,0.1); padding-top: 10px;">
        <a href="../logout.php" onclick="return confirm('Apakah anda yakin ingin keluar?')" style="color: #ff7675; font-weight: bold;">Logout</a>
    </li>
</ul>
            </ul>
        </aside>

        <main class="main-content">
            <div class="content-header">
                <h1>Laporan Statistik</h1>
            </div>

            <div class="stats-grid" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin-bottom: 30px;">
                <div class="stat-card" style="background: white; padding: 20px; border-radius: 10px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); border-left: 5px solid #667eea;">
                    <h3 style="color: #777; font-size: 0.9rem;">Total Buku</h3>
                    <div class="stat-value" style="font-size: 2rem; font-weight: bold; color: #333;"><?php echo $d_buku['total'] ?? 0; ?></div>
                </div>
                <div class="stat-card" style="background: white; padding: 20px; border-radius: 10px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); border-left: 5px solid #764ba2;">
                    <h3 style="color: #777; font-size: 0.9rem;">Total Anggota</h3>
                    <div class="stat-value" style="font-size: 2rem; font-weight: bold; color: #333;"><?php echo $d_agt['total'] ?? 0; ?></div>
                </div>
                <div class="stat-card" style="background: white; padding: 20px; border-radius: 10px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); border-left: 5px solid #f39c12;">
                    <h3 style="color: #777; font-size: 0.9rem;">Sedang Dipinjam</h3>
                    <div class="stat-value" style="font-size: 2rem; font-weight: bold; color: #f39c12;"><?php echo $d_pinjam['total'] ?? 0; ?></div>
                </div>
                <div class="stat-card" style="background: white; padding: 20px; border-radius: 10px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); border-left: 5px solid #2ecc71;">
                    <h3 style="color: #777; font-size: 0.9rem;">Sudah Dikembalikan</h3>
                    <div class="stat-value" style="font-size: 2rem; font-weight: bold; color: #2ecc71;"><?php echo $d_kembali['total'] ?? 0; ?></div>
                </div>
            </div>

            <div class="content-box" style="background:white; padding:25px; border-radius:10px; box-shadow:0 2px 10px rgba(0,0,0,0.05);">
                <h2 style="margin-bottom: 1.5rem; border-bottom: 2px solid #f1f1f1; padding-bottom: 10px;">5 Riwayat Transaksi Terakhir</h2>
                <div class="table-container">
                    <table style="width: 100%; border-collapse: collapse;">
                        <thead>
                            <tr style="background: #f8f9fa; text-align: left;">
                                <th style="padding: 12px; border-bottom: 2px solid #dee2e6;">Tgl Pinjam</th>
                                <th style="padding: 12px; border-bottom: 2px solid #dee2e6;">Nama Anggota</th>
                                <th style="padding: 12px; border-bottom: 2px solid #dee2e6;">Judul Buku</th>
                                <th style="padding: 12px; border-bottom: 2px solid #dee2e6;">Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $log = mysqli_query($koneksi, "SELECT t.*, b.judul, a.nama_lengkap 
                                                           FROM tbl_transaksi t
                                                           JOIN tbl_buku b ON t.id_buku = b.id_buku
                                                           JOIN tbl_anggota a ON t.id_anggota = a.id_anggota
                                                           ORDER BY t.id_transaksi DESC LIMIT 5");
                            while($r = mysqli_fetch_array($log)){
                            ?>
                            <tr>
                                <td style="padding: 12px; border-bottom: 1px solid #eee;"><?php echo $r['tgl_pinjam']; ?></td>
                                <td style="padding: 12px; border-bottom: 1px solid #eee;"><?php echo $r['nama_lengkap']; ?></td>
                                <td style="padding: 12px; border-bottom: 1px solid #eee;"><?php echo $r['judul']; ?></td>
                                <td style="padding: 12px; border-bottom: 1px solid #eee;">
                                    <?php 
                                    if($r['status'] == 'Dipinjam'){ 
                                        echo "<span style='color:#f39c12; font-weight:bold;'>🟡 Dipinjam</span>"; 
                                    } elseif($r['status'] == 'Telat') { 
                                        echo "<span style='color:#e74c3c; font-weight:bold;'>🔴 Telat</span>"; 
                                    } else { 
                                        echo "<span style='color:#2ecc71; font-weight:bold;'>🟢 Kembali</span>"; 
                                    } 
                                    ?>
                                </td>
                            </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </main>
    </div>
</body>
</html>