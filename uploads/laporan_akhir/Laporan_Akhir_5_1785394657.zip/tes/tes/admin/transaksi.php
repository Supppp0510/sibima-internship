<?php
session_start();
// 1. Jalur koneksi naik satu tingkat
include '../koneksi.php';

// Atur zona waktu agar sinkron
date_default_timezone_set('Asia/Jakarta');

// 2. Proteksi Halaman
if (!isset($_SESSION['status']) || $_SESSION['status'] != "login" || $_SESSION['role'] != "admin") {
    header("location:../index.php?pesan=belum_login");
    exit();
}

// 3. AMBIL ATURAN AKTIF DARI PENGATURAN (Untuk perhitungan jatuh tempo & tarif denda)
$query_setting = mysqli_query($koneksi, "SELECT * FROM tbl_pengaturan WHERE id=1");
$setting       = mysqli_fetch_assoc($query_setting);
$batas_hari    = isset($setting['durasi_pinjam']) ? $setting['durasi_pinjam'] : 7;
$tarif_denda   = isset($setting['denda_per_hari']) ? $setting['denda_per_hari'] : 500;

// 4. OTOMATISASI STATUS JATUH TEMPO (Krono-Bot)
// Setiap kali halaman dibuka, cek transaksi 'Dipinjam' yang sudah melewati tanggal seharusnya kembali
$hari_ini = date('Y-m-d');
$cek_jatuh_tempo = mysqli_query($koneksi, "SELECT * FROM tbl_transaksi WHERE status='Dipinjam'");
while ($row = mysqli_fetch_assoc($cek_jatuh_tempo)) {
    $id_tfx = $row['id_transaksi'];
    $tgl_wajib = $row['tgl_harus_kembali'];
    
    if ($hari_ini > $tgl_wajib) {
        $selisih_detik = strtotime($hari_ini) - strtotime($tgl_wajib);
        $jumlah_hari   = floor($selisih_detik / (60 * 60 * 24));
        $total_denda   = $jumlah_hari * $tarif_denda;
        
        mysqli_query($koneksi, "UPDATE tbl_transaksi SET status='Telat', total_denda='$total_denda' WHERE id_transaksi='$id_tfx'");
    }
}

// 5. PROSES SIMPAN PINJAM
$pesan_sukses = "";
if (isset($_POST['pinjam'])) {
    $id_buku           = $_POST['id_buku'];
    $id_anggota        = $_POST['id_anggota'];
    $tgl_pinjam        = $_POST['tgl_pinjam'];
    $tgl_harus_kembali = $_POST['tgl_harus_kembali'];
    
    $cek_stok = mysqli_query($koneksi, "SELECT stok FROM tbl_buku WHERE id_buku='$id_buku'");
    $data_stok = mysqli_fetch_assoc($cek_stok);

    if ($data_stok['stok'] > 0) {
        // Query disesuaikan dengan struktur tabel rekomendasi baru
        $simpan = mysqli_query($koneksi, "INSERT INTO tbl_transaksi (id_buku, id_anggota, tgl_pinjam, tgl_harus_kembali, status, total_denda) VALUES ('$id_buku', '$id_anggota', '$tgl_pinjam', '$tgl_harus_kembali', 'Dipinjam', 0)");
        mysqli_query($koneksi, "UPDATE tbl_buku SET stok = stok - 1 WHERE id_buku='$id_buku'");
        if ($simpan) {
            $pesan_sukses = "pinjam_berhasil";
        }
    } else {
        $pesan_sukses = "stok_habis";
    }
}

// 6. PROSES UPDATE KEMBALI / RUBAH STATUS DARI TOMBOL CEK MODAL
if (isset($_POST['update_status_transaksi'])) {
    $id_transaksi = $_POST['modal_id_transaksi'];
    $status_baru  = $_POST['modal_status'];
    $id_buku      = $_POST['modal_id_buku'];
    
    // Ambil status lama untuk tahu sirkulasi stok buku
    $status_lama_q = mysqli_query($koneksi, "SELECT status FROM tbl_transaksi WHERE id_transaksi='$id_transaksi'");
    $status_lama   = mysqli_fetch_assoc($status_lama_q)['status'];

    if ($status_baru == 'Dikembalikan') {
        $tgl_kembali = date('Y-m-d');
        
        // Ambil data denda akhir saat dikembalikan
        $tgl_q = mysqli_query($koneksi, "SELECT tgl_harus_kembali FROM tbl_transaksi WHERE id_transaksi='$id_transaksi'");
        $tgl_wajib = mysqli_fetch_assoc($tgl_q)['tgl_harus_kembali'];
        
        $akhir_denda = 0;
        if($tgl_kembali > $tgl_wajib) {
            $selisih = strtotime($tgl_kembali) - strtotime($tgl_wajib);
            $hari    = floor($selisih / (60 * 60 * 24));
            $akhir_denda = $hari * $tarif_denda;
        }

        $update = mysqli_query($koneksi, "UPDATE tbl_transaksi SET status='Dikembalikan', tgl_kembali='$tgl_kembali', total_denda='$akhir_denda' WHERE id_transaksi='$id_transaksi'");
        
        // Kembalikan stok jika sebelumnya statusnya belum Dikembalikan
        if($status_lama != 'Dikembalikan') {
            mysqli_query($koneksi, "UPDATE tbl_buku SET stok = stok + 1 WHERE id_buku='$id_buku'");
        }
    } else {
        // Jika diubah manual kembali ke 'Dipinjam' atau 'Telat' oleh admin
        $update = mysqli_query($koneksi, "UPDATE tbl_transaksi SET status='$status_baru', tgl_kembali=NULL WHERE id_transaksi='$id_transaksi'");
        
        // Kurangi stok kembali jika sebelumnya bernilai Dikembalikan
        if($status_lama == 'Dikembalikan') {
            mysqli_query($koneksi, "UPDATE tbl_buku SET stok = stok - 1 WHERE id_buku='$id_buku'");
        }
    }

    if ($update) {
        header("location:transaksi.php?pesan=update_berhasil");
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Transaksi - Admin Litera-Z</title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        .dataTables_wrapper { margin-top: 20px; font-family: sans-serif; font-size: 0.9rem; }
        .form-control { width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 6px; outline: none; transition: 0.3s; }
        .form-control:focus { border-color: #667eea; box-shadow: 0 0 5px rgba(102,126,234,0.3); }
        .btn-pinjam { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color:white; border:none; padding:12px 25px; border-radius:6px; cursor:pointer; font-weight: bold; width: 100%; margin-top: 10px; }
        .badge { padding: 5px 12px; border-radius: 20px; font-size: 0.75rem; font-weight: bold; display: inline-block; }
        .badge-warning { background: #fef3c7; color: #d97706; }
        .badge-danger { background: #fee2e2; color: #ef4444; }
        .badge-success { background: #dcfce7; color: #22c55e; }        
        
        /* Layout DataTables */
        .dataTables_wrapper .top { display: flex; justify-content: flex-end; margin-bottom: 15px; }
        .dataTables_wrapper .bottom { display: flex; justify-content: space-between; align-items: center; margin-top: 15px; padding-top: 10px; border-top: 1px solid #eee; }
        
        /* Styling Search & Show Entries */
        .dataTables_length select, .dataTables_filter input { padding: 6px 10px; border: 1px solid #ddd; border-radius: 6px; outline: none; font-family: inherit; transition: 0.3s; }
        .dataTables_length select:focus, .dataTables_filter input:focus { border-color: #667eea; box-shadow: 0 0 5px rgba(102,126,234,0.3); }
        .dataTables_filter input { margin-left: 10px; }
        .dataTables_length select { margin: 0 5px; cursor: pointer; }

        /* Modal Style Rincian */
        .modal { display: none; position: fixed; z-index: 9999; left: 0; top: 0; width: 100%; height: 100%; overflow: auto; background-color: rgba(0,0,0,0.5); }
        .modal-content { background-color: #fefefe; margin: 5% auto; padding: 25px; border: 1px solid #888; width: 50%; border-radius: 12px; box-shadow: 0 5px 15px rgba(0,0,0,0.3); animation: slideDown 0.3s ease; }
        @keyframes slideDown { from {transform: translateY(-50px); opacity: 0;} to {transform: translateY(0); opacity: 1;} }
        .modal-grid { display: grid; grid-template-columns: 1fr 2fr; gap: 20px; margin-top: 15px; }
        .detail-row { display: flex; margin-bottom: 10px; border-bottom: 1px solid #f1f2f6; padding-bottom: 8px; }
        .detail-label { width: 150px; font-weight: bold; color: #555; }
        .detail-value { color: #333; }
    </style>
</head>
<body>
    <div class="dashboard-container">
        <aside class="sidebar">
            <div class="sidebar-header">
                <img src="../img/logo1.png" alt="Logo Litera-Z" class="sidebar-logo">
            </div>
            <ul class="sidebar-menu">
                <li><a href="index.php">Dashboard</a></li>
                <li><a href="buku.php">Data Buku</a></li> 
                <li><a href="rak.php">Rak Buku</a></li>
                <li><a href="anggota.php">Data Anggota</a></li>
                <li><a href="transaksi.php" class="active">Peminjaman</a></li>
                <li><a href="laporan.php">Laporan</a></li>
                <li><a href="pengaturan.php">Pengaturan</a></li>
            <li style="margin-top: 15px; border-top: 1px solid rgba(255,255,255,0.1); padding-top: 10px;">
        <a href="../logout.php" onclick="return confirm('Apakah anda yakin ingin keluar?')" style="color: #ff7675; font-weight: bold;">Logout</a>
    </li>
</ul>
            </ul>
        </aside>

        <main class="main-content">
            <div class="content-header">
                <h1>Transaksi Peminjaman</h1>
            </div>
            
            <div class="content-box" style="background:white; padding:25px; border-radius:12px; box-shadow:0 4px 15px rgba(0,0,0,0.05); margin-bottom: 2rem;">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem;">
                    <h2 style="margin: 0; color: #2d3748;">Riwayat Transaksi</h2>
                    <button type="button" id="btnToggleForm" onclick="toggleFormTransaksi()" style="background: #667eea; color: white; border: none; padding: 10px 20px; border-radius: 6px; cursor: pointer; font-weight: bold; transition: 0.2s;">
                        + Entri Peminjaman Baru
                    </button>
                </div>
                
                <table id="tabelTransaksi" class="display" style="width:100%">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Judul Buku</th>
                            <th>Peminjam</th>
                            <th>Tgl Pinjam</th>
                            <th>Harus Kembali</th>
                            <th>Tgl Kembali</th>
                            <th>Status</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $no = 1;
                        // Query Gabungan Menggunakan Struktur Tabel Baru
                        $query = "SELECT t.*, b.judul, b.cover, a.nama_lengkap 
                                  FROM tbl_transaksi t 
                                  JOIN tbl_buku b ON t.id_buku = b.id_buku 
                                  JOIN tbl_anggota a ON t.id_anggota = a.id_anggota 
                                  ORDER BY t.id_transaksi DESC";
                        $tampil = mysqli_query($koneksi, $query);
                        while($data = mysqli_fetch_array($tampil)){
                        ?>
                        <tr>
                            <td><?php echo $no++; ?></td>
                            <td style="font-weight: 500;"><?php echo $data['judul']; ?></td>
                            <td><?php echo $data['nama_lengkap']; ?></td>
                            <td><?php echo date('d/m/Y', strtotime($data['tgl_pinjam'])); ?></td>
                            <td><?php echo date('d/m/Y', strtotime($data['tgl_harus_kembali'])); ?></td>
                            <td><?php echo ($data['tgl_kembali'] == NULL || $data['tgl_kembali'] == '0000-00-00') ? "<small style='color:#ccc'>-</small>" : date('d/m/Y', strtotime($data['tgl_kembali'])); ?></td>
                            <td>
                                <?php if($data['status'] == 'Dipinjam'){ ?>
                                    <span class="badge badge-warning">Dipinjam</span>
                                <?php } elseif($data['status'] == 'Telat') { ?>
                                    <span class="badge badge-danger">Telat</span>
                                <?php } else { ?>
                                    <span class="badge badge-success">Dikembalikan</span>
                                <?php } ?>
                            </td>
                            <td>
                                <button type="button" onclick="bukaModalCek(<?php echo htmlspecialchars(json_encode($data)); ?>)" style="background:#3498db; border:none; padding:6px 12px; color:white; cursor:pointer; border-radius:4px; font-size:0.75rem; font-weight: bold;">
                                    🔍 Cek
                                </button>
                                <a href="print_nota.php?id=<?php echo $data['id_transaksi']; ?>" target="_blank" style="background:#2ecc71; padding:6px 12px; color:white; border-radius:4px; font-size:0.75rem; font-weight: bold; text-decoration: none; margin-left: 4px;">
                                    🖨️ Print
                                </a>
                            </td>
                        </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>

            <div id="containerFormTransaksi" class="content-box" style="display: none; background:white; padding:25px; border-radius:12px; box-shadow:0 4px 15px rgba(0,0,0,0.05); margin-bottom: 2rem;">
                <h2 style="margin-bottom: 1.5rem; color: #2d3748;">Entri Peminjaman Baru</h2>
                <form action="" method="POST" id="formPinjam">
                    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 20px;">
                        
                        <div class="form-group">
                            <label style="display:block; margin-bottom:8px; font-weight:600; color:#4a5568;">Pilih Buku</label>
                            <select name="id_buku" required class="form-control">
                                <option value="">-- Cari Judul Buku --</option>
                                <?php
                                $sql_buku = mysqli_query($koneksi, "SELECT * FROM tbl_buku WHERE stok > 0 ORDER BY judul ASC");
                                while($buku = mysqli_fetch_array($sql_buku)){
                                    echo "<option value='".$buku['id_buku']."'>".$buku['judul']." (Sisa: ".$buku['stok'].")</option>";
                                }
                                ?>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label style="display:block; margin-bottom:8px; font-weight:600; color:#4a5568;">Pilih Anggota</label>
                            <select name="id_anggota" required class="form-control">
                                <option value="">-- Pilih Nama Anggota --</option>
                                <?php
                                $sql_agt = mysqli_query($koneksi, "SELECT * FROM tbl_anggota ORDER BY nama_lengkap ASC");
                                while($agt = mysqli_fetch_array($sql_agt)){
                                    echo "<option value='".$agt['id_anggota']."'>".$agt['nis']." - ".$agt['nama_lengkap']."</option>";
                                }
                                ?>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label style="display:block; margin-bottom:8px; font-weight:600; color:#4a5568;">Tanggal Pinjam</label>
                            <input type="date" id="tgl_pinjam" name="tgl_pinjam" value="<?php echo date('Y-m-d'); ?>" onchange="hitungJatuhTempo()" required class="form-control">
                        </div>

                        <div class="form-group">
                            <label style="display:block; margin-bottom:8px; font-weight:600; color:#4a5568;">Tanggal Wajib Kembali</label>
                            <input type="date" id="tgl_harus_kembali" name="tgl_harus_kembali" readonly class="form-control" style="background: #f7fafc; font-weight: bold; color: #2d3748;">
                            <small style="color: #a0aec0; display:block; margin-top:4px;">*Otomatis bertambah +<?php echo $batas_hari; ?> Hari.</small>
                        </div>

                    </div>
                    <button type="submit" name="pinjam" class="btn-pinjam">Proses Peminjaman</button>
                </form>
            </div>
        </main>
    </div>

    <div id="modalRincian" class="modal">
        <div class="modal-content">
            <h2 style="margin-top:0; border-bottom: 2px solid #667eea; padding-bottom: 10px; color:#333;">Rincian Peminjaman Buku</h2>
            <form action="" method="POST">
                <input type="hidden" name="modal_id_transaksi" id="modal_id_transaksi">
                <input type="hidden" name="modal_id_buku" id="modal_id_buku">
                
                <div class="modal-grid">
                    <div style="text-align: center; background: #f8fafc; padding: 10px; border-radius: 8px; border: 1px solid #e2e8f0;">
                        <img id="detail_cover" src="../img/no-cover.jpg" alt="Cover Buku" style="max-width: 100%; max-height: 220px; border-radius: 4px; box-shadow: 0 2px 5px rgba(0,0,0,0.15);">
                    </div>
                    
                    <div>
                        <div class="detail-row">
                            <div class="detail-label">Peminjam</div>
                            <div class="detail-value" id="detail_peminjam"></div>
                        </div>
                        <div class="detail-row">
                            <div class="detail-label">Judul Buku</div>
                            <div class="detail-value" id="detail_judul" style="font-weight: bold;"></div>
                        </div>
                        <div class="detail-row">
                            <div class="detail-label">Tanggal Pinjam</div>
                            <div class="detail-value" id="detail_tgl_pinjam"></div>
                        </div>
                        <div class="detail-row">
                            <div class="detail-label">Harus Kembali</div>
                            <div class="detail-value" id="detail_harus_kembali" style="color: #e74c3c; font-weight: bold;"></div>
                        </div>
                        <div class="detail-row">
                            <div class="detail-label">Tgl Pengembalian</div>
                            <div class="detail-value" id="detail_tgl_kembali">-</div>
                        </div>
                        <div class="detail-row">
                            <div class="detail-label">Denda Terlambat</div>
                            <div class="detail-value" id="detail_denda" style="color: #ef4444; font-weight: bold;"></div>
                        </div>
                        <div class="detail-row" style="border:none; align-items: center; margin-top:15px;">
                            <div class="detail-label">Status Transaksi</div>
                            <div class="detail-value">
                                <select name="modal_status" id="modal_status" class="form-control" style="padding: 6px 10px; font-weight: bold;">
                                    <option value="Dipinjam">Dipinjam</option>
                                    <option value="Telat">Telat</option>
                                    <option value="Dikembalikan">Dikembalikan</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>

                <div style="display: flex; justify-content: flex-end; gap: 10px; margin-top: 25px; border-top: 1px solid #e2e8f0; padding-top: 15px;">
                    <button type="button" onclick="tutupModalCek()" style="background: #94a3b8; color: white; border: none; padding: 10px 20px; border-radius: 6px; cursor: pointer; font-weight: bold;">Kembali</button>
                    <button type="submit" name="update_status_transaksi" style="background: #667eea; color: white; border: none; padding: 10px 25px; border-radius: 6px; cursor: pointer; font-weight: bold;">Simpan</button>
                </div>
            </form>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
    
    <script>
        $(document).ready(function () {
            // DataTables Setup
            $('#tabelTransaksi').DataTable({ 
                "dom": '<"top"f>rt<"bottom"ilp><"clear">',
                "language": { "url": "//cdn.datatables.net/plug-ins/1.13.4/i18n/id.json" } 
            });

            // Jalankan hitung jatuh tempo saat pertama kali render form (jika terbuka)
            hitungJatuhTempo();

            // SweetAlert Notifikasi
            <?php if($pesan_sukses == "pinjam_berhasil"): ?>
                Swal.fire('Berhasil!', 'Peminjaman buku telah berhasil dicatat.', 'success');
            <?php elseif($pesan_sukses == "stok_habis"): ?>
                Swal.fire('Gagal!', 'Maaf, stok buku ini sedang habis di rak.', 'error');
            <?php endif; ?>

            <?php if(isset($_GET['pesan']) && $_GET['pesan'] == "update_berhasil"): ?>
                Swal.fire('Berhasil!', 'Status transaksi & sirkulasi denda diperbarui.', 'success');
            <?php endif; ?>
        });

        // 1. Fungsi Buka-Tutup Form Peminjaman Baru
        function toggleFormTransaksi() {
            var formBox = document.getElementById("containerFormTransaksi");
            var btn = document.getElementById("btnToggleForm");
            
            if (formBox.style.display === "none") {
                formBox.style.display = "block";
                btn.innerHTML = "✖ Tutup Form Entri";
                btn.style.background = "#e74c3c";
                hitungJatuhTempo();
                formBox.scrollIntoView({ behavior: 'smooth' });
            } else {
                formBox.style.display = "none";
                btn.innerHTML = "+ Entri Peminjaman Baru";
                btn.style.background = "#667eea";
            }
        }

        // 2. Fungsi Hitung Otomatis Jatuh Tempo JavaScript
        function hitungJatuhTempo() {
            var tglPinjamInput = document.getElementById('tgl_pinjam').value;
            var batasHari = <?php echo $batas_hari; ?>; 
            
            if(tglPinjamInput) {
                var tglPinjam = new Date(tglPinjamInput);
                tglPinjam.setDate(tglPinjam.getDate() + batasHari);
                
                var yyyy = tglPinjam.getFullYear();
                var mm = String(tglPinjam.getMonth() + 1).padStart(2, '0');
                var dd = String(tglPinjam.getDate()).padStart(2, '0');
                
                document.getElementById('tgl_harus_kembali').value = yyyy + '-' + mm + '-' + dd;
            }
        }

        // 3. Fungsi Format Tanggal dari YYYY-MM-DD ke DD/MM/YYYY
        function formatTanggalIndo(stringTanggal) {
            if(!stringTanggal || stringTanggal === '0000-00-00') return '-';
            var d = new Date(stringTanggal);
            var tgl = String(d.getDate()).padStart(2, '0');
            var bln = String(d.getMonth() + 1).padStart(2, '0');
            var thn = d.getFullYear();
            return tgl + '/' + bln + '/' + thn;
        }

        // 4. Fungsi Menampilkan Modal Pop-up Rincian & Pilihan Status
        function bukaModalCek(data) {
            document.getElementById('modal_id_transaksi').value = data.id_transaksi;
            document.getElementById('modal_id_buku').value = data.id_buku;
            document.getElementById('detail_peminjam').innerText = data.nama_lengkap;
            document.getElementById('detail_judul').innerText = data.judul;
            document.getElementById('detail_tgl_pinjam').innerText = formatTanggalIndo(data.tgl_pinjam);
            document.getElementById('detail_harus_kembali').innerText = formatTanggalIndo(data.tgl_harus_kembali);
            
            // Atur Tgl Pengembalian Riil
            if(data.tgl_kembali && data.tgl_kembali !== '0000-00-00') {
                document.getElementById('detail_tgl_kembali').innerText = formatTanggalIndo(data.tgl_kembali);
            } else {
                document.getElementById('detail_tgl_kembali').innerText = '-';
            }

            // Atur Nominal Denda Terformat Rupiah
            var rupiah = new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', minimumFractionDigits: 0 }).format(data.total_denda);
            document.getElementById('detail_denda').innerText = rupiah;

            // Atur Cover Buku
            if(data.cover && data.cover !== '') {
                document.getElementById('detail_cover').src = "../img/" + data.cover;
            } else {
                document.getElementById('detail_cover').src = "../img/no-cover.jpg";
            }

            // Sinkronkan Nilai Dropdown Pilihan Status Di Modal
            document.getElementById('modal_status').value = data.status;

            // Tampilkan Modal ke Atas Layar
            document.getElementById('modalRincian').style.display = "block";
        }

        // 5. Tutup Modal Cek
        function tutupModalCek() {
            document.getElementById('modalRincian').style.display = "none";
        }
    </script>
</body>
</html>