<?php
session_start();
include '../koneksi.php';

if (!isset($_SESSION['status']) || $_SESSION['status'] != "login" || $_SESSION['role'] != "admin") {
    header("location:../index.php?pesan=belum_login");
    exit();
}

$v_judul = $v_penulis = $v_isbn = $v_tahun = $v_stok = $v_rak = "";

// 1. PROSES SIMPAN BUKU BARU + UPLOAD COVER
if (isset($_POST['simpan'])) {
    $v_judul   = mysqli_real_escape_string($koneksi, $_POST['judul']);
    $v_penulis = mysqli_real_escape_string($koneksi, $_POST['penulis']);
    $v_isbn    = mysqli_real_escape_string($koneksi, $_POST['isbn']);
    $v_tahun   = $_POST['tahun'];
    $v_stok    = $_POST['stok'];
    $v_rak     = $_POST['id_rak'];

    // Handle Upload Gambar
    $nama_file = $_FILES['cover']['name'];
    $tmp_file  = $_FILES['cover']['tmp_name'];
    $ekstensi  = pathinfo($nama_file, PATHINFO_EXTENSION);
    $nama_baru = ($nama_file != "") ? date('dmYHis')."_".rand(100,999).".".$ekstensi : "default.jpg";
    $path      = "../cover/".$nama_baru;

    if (!preg_match('/^[0-9]{13}$/', $v_isbn)) {
        echo "<script>alert('ISBN harus 13 digit!');</script>";
    } else {
        $cek_isbn = mysqli_query($koneksi, "SELECT * FROM tbl_buku WHERE isbn = '$v_isbn'");
        if (mysqli_num_rows($cek_isbn) > 0) {
            echo "<script>alert('ISBN sudah terdaftar!');</script>";
        } else {
            // Upload file ke folder cover
            if ($nama_file != "") { move_uploaded_file($tmp_file, $path); }

            $simpan = mysqli_query($koneksi, "INSERT INTO tbl_buku (judul, penulis, isbn, tahun_terbit, stok, id_rak, cover) 
                                             VALUES ('$v_judul', '$v_penulis', '$v_isbn', '$v_tahun', '$v_stok', '$v_rak', '$nama_baru')");
            if ($simpan) {
                echo "<script src='https://cdn.jsdelivr.net/npm/sweetalert2@11'></script>";
                echo "<script>setTimeout(function() { Swal.fire({title: 'Berhasil!', text: 'Buku Disimpan!', icon: 'success'}).then(() => { window.location='buku.php'; }); }, 100);</script>";
            }
        }
    }
}

// 2. PROSES UPDATE BUKU + GANTI COVER
if (isset($_POST['update_buku'])) {
    $id_buku = $_POST['id_buku'];
    $judul   = mysqli_real_escape_string($koneksi, $_POST['judul']);
    $isbn    = mysqli_real_escape_string($koneksi, $_POST['isbn']);
    $stok    = $_POST['stok'];
    $id_rak  = $_POST['id_rak'];

    // Cek file baru
    $nama_file = $_FILES['cover']['name'];
    $tmp_file  = $_FILES['cover']['tmp_name'];

    if ($nama_file != "") {
        // Hapus file lama jika ada
        $data_lama = mysqli_fetch_array(mysqli_query($koneksi, "SELECT cover FROM tbl_buku WHERE id_buku='$id_buku'"));
        if ($data_lama['cover'] != "default.jpg" && file_exists("../cover/".$data_lama['cover'])) {
            unlink("../cover/".$data_lama['cover']);
        }
        // Upload yang baru
        $ekstensi = pathinfo($nama_file, PATHINFO_EXTENSION);
        $nama_baru = date('dmYHis')."_".rand(100,999).".".$ekstensi;
        move_uploaded_file($tmp_file, "../cover/".$nama_baru);
        
        $sql_update = "UPDATE tbl_buku SET judul='$judul', isbn='$isbn', stok='$stok', id_rak='$id_rak', cover='$nama_baru' WHERE id_buku='$id_buku'";
    } else {
        $sql_update = "UPDATE tbl_buku SET judul='$judul', isbn='$isbn', stok='$stok', id_rak='$id_rak' WHERE id_buku='$id_buku'";
    }

    mysqli_query($koneksi, $sql_update);
    header("location:buku.php");
}

// 3. HAPUS DATA BUKU + HAPUS FILE GAMBARNYA
if (isset($_GET['aksi']) && $_GET['aksi'] == 'hapus') {
    $id = $_GET['id'];
    $data = mysqli_fetch_array(mysqli_query($koneksi, "SELECT cover FROM tbl_buku WHERE id_buku='$id'"));
    if ($data['cover'] != "default.jpg" && file_exists("../cover/".$data['cover'])) {
        unlink("../cover/".$data['cover']);
    }
    mysqli_query($koneksi, "DELETE FROM tbl_transaksi WHERE id_buku='$id'");
    mysqli_query($koneksi, "DELETE FROM tbl_buku WHERE id_buku='$id'");
    header("location:buku.php");
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Data Buku - Admin Litera-Z</title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css">
    <style>
        .dataTables_wrapper { margin-top: 20px; font-family: sans-serif; font-size: 0.9rem; }
        .modal-stok { display: none; position: fixed; z-index: 1000; left: 0; top: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); }
        .modal-content { background: white; margin: 5% auto; padding: 20px; width: 450px; border-radius: 8px; max-height: 90vh; overflow-y: auto; }
        .dataTables_wrapper .bottom { display: flex; justify-content: space-between; align-items: center; margin-top: 15px; padding-top: 10px; border-top: 1px solid #eee; }
    </style>
</head>
<body>

    <div id="modalEdit" class="modal-stok"> 
        <div class="modal-content">
            <h3>Edit Data Buku</h3><hr>
            <form action="" method="POST" enctype="multipart/form-data">
                <input type="hidden" name="id_buku" id="edit_id_buku">
                <div style="margin-bottom: 10px; text-align: center;">
                    <img id="preview_cover" src="" style="width: 120px; height: 160px; object-fit: cover; border-radius: 5px; border: 1px solid #ddd; display: block; margin: 0 auto 10px;">
                </div>
                <div style="margin-bottom: 10px;">
                    <label>Judul Buku</label>
                    <input type="text" name="judul" id="edit_judul" required style="width: 100%; padding: 8px; box-sizing: border-box;">
                </div>
                <div style="margin-bottom: 10px;">
                    <label>ISBN</label>
                    <input type="text" name="isbn" id="edit_isbn" required style="width: 100%; padding: 8px; box-sizing: border-box;">
                </div>
                <div style="margin-bottom: 10px;">
                    <label>Lokasi Rak</label>
                    <select name="id_rak" id="edit_rak" required style="width: 100%; padding: 8px;">
                        <?php 
                        $r_query = mysqli_query($koneksi, "SELECT * FROM tbl_rak");
                        while($r = mysqli_fetch_array($r_query)){ echo "<option value='".$r['id_rak']."'>".$r['nama_rak']."</option>"; }
                        ?>
                    </select>
                </div>
                <div style="margin-bottom: 10px;">
                    <label>Stok</label>
                    <input type="number" name="stok" id="edit_stok" required style="width: 100%; padding: 8px; box-sizing: border-box;">
                </div>
                <div style="margin-bottom: 15px;">
                    <label>Ganti Cover (Kosongkan jika tidak diubah)</label>
                    <input type="file" name="cover" accept="image/*" style="width: 100%; padding: 8px;">
                </div>
                <button type="submit" name="update_buku" style="background:#f1c40f; color:white; border:none; padding:10px 20px; border-radius:4px; cursor:pointer;">Update</button>
                <button type="button" onclick="tutupModalEdit()" style="background:#95a5a6; color:white; border:none; padding:10px 20px; border-radius:4px;">Batal</button>
            </form>
        </div>
    </div>

    <div class="dashboard-container">
        <aside class="sidebar">
            <div class="sidebar-header">
            <img src="../img/logo1.png" alt="Logo Litera-Z" class="sidebar-logo"></div>
            <ul class="sidebar-menu">
                <li><a href="index.php">Dashboard</a></li>
                <li><a href="buku.php" class="active">Data Buku</a></li>
                <li><a href="rak.php">Rak Buku</a></li>
                <li><a href="anggota.php">Data Anggota</a></li>
                <li><a href="transaksi.php">Peminjaman</a></li>
                <li><a href="laporan.php">Laporan</a></li>
                <li><a href="pengaturan.php">Pengaturan</a></li>
            <li style="margin-top: 15px; border-top: 1px solid rgba(255,255,255,0.1); padding-top: 10px;">
        <a href="../logout.php" onclick="return confirm('Apakah anda yakin ingin keluar?')" style="color: #ff7675; font-weight: bold;">Logout</a>
    </li>
</ul>
            </ul>
        </aside>

        <main class="main-content">
            <div class="content-header">
                <h1>Data Buku</h1>
            </div>

            <div class="content-box" style="background:white; padding:20px; border-radius:10px; margin-bottom:20px;">
                <h2 style="margin-bottom: 1rem;">Daftar Buku</h2>
                <button type="button" id="btnToggleBuku" onclick="toggleFormBuku()" style="background: #667eea; color: white; border: none; padding: 10px 18px; border-radius: 6px; cursor: pointer; font-weight: bold; font-family: inherit; font-size: 13px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); transition: all 0.3s ease;">+ Tambah Buku
                </button>
                <table id="tabelKu" class="display" style="width:100%">
                    <thead>
                        <tr><th>No</th><th>Judul</th><th>ISBN</th><th>Rak</th><th>Stok</th><th>Aksi</th></tr>
                    </thead>
                    <tbody>
                        <?php
                        $no = 1;
                        $tampil = mysqli_query($koneksi, "SELECT tbl_buku.*, tbl_rak.nama_rak, tbl_rak.kode_rak FROM tbl_buku LEFT JOIN tbl_rak ON tbl_buku.id_rak = tbl_rak.id_rak ORDER BY id_buku DESC");
                        while($data = mysqli_fetch_array($tampil)){
                        ?>
                        <tr>
                            <td><?php echo $no++; ?></td>
                            <td><?php echo $data['judul']; ?></td>
                            <td><?php echo $data['isbn']; ?></td> 
                            <td><?php echo ($data['nama_rak'] == NULL) ? "-" : $data['kode_rak']." (".$data['nama_rak'].")"; ?></td>
                            <td><?php echo $data['stok']; ?></td>
                            <td>
                                <button onclick="bukaModalEdit('<?php echo $data['id_buku']; ?>', '<?php echo addslashes($data['judul']); ?>', '<?php echo $data['isbn']; ?>', '<?php echo $data['id_rak']; ?>', '<?php echo $data['stok']; ?>', '<?php echo $data['cover']; ?>')" style="background:#f1c40f; color:white; border:none; padding:5px 8px; border-radius:4px; cursor:pointer;">Edit</button>
                                <a href="#" onclick="konfirmasiHapus('buku.php?aksi=hapus&id=<?php echo $data['id_buku']; ?>')" style="background:#e74c3c; padding:5px 10px; color:white; text-decoration:none; border-radius:4px; font-size:0.75rem;">Hapus</a>
                            </td>
                        </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>

            <div id="containerFormBuku" class="content-box" style="display: none; margin-bottom: 2rem; background:white; padding:20px; border-radius:10px; box-shadow:0 2px 5px rgba(0,0,0,0.1);">
                <h2>Tambah Buku Baru</h2><br>
                <form action="" method="POST" enctype="multipart/form-data">
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin-bottom: 15px;">
                        <div class="form-group">
                            <label>Judul Buku</label>
                            <input type="text" name="judul" required style="width:100%; padding:10px; border:1px solid #ddd; border-radius:5px; box-sizing: border-box;">
                        </div>
                        <div class="form-group">
                            <label>Penulis</label>
                            <input type="text" name="penulis" required style="width:100%; padding:10px; border:1px solid #ddd; border-radius:5px; box-sizing: border-box;">
                        </div>
                    </div>
                    <div style="display: grid; grid-template-columns: 1fr 1fr 1fr 1fr; gap: 15px; margin-bottom: 15px;">
                        <div class="form-group">
                            <label>ISBN (13 Digit)</label> 
                            <input type="text" name="isbn" id="isbn_input" required maxlength="13" minlength="13" pattern="[0-9]{13}" style="width:100%; padding:10px; border:1px solid #ddd; border-radius:5px; box-sizing: border-box;">
                        </div>
                        <div class="form-group">
                            <label>Tahun Terbit</label>
                            <input type="number" name="tahun" min="1900" max="2099" required style="width:100%; padding:10px; border:1px solid #ddd; border-radius:5px; box-sizing: border-box;">
                        </div>
                        <div class="form-group">
                            <label>Stok Awal</label>
                            <input type="number" name="stok" min="1" required style="width:100%; padding:10px; border:1px solid #ddd; border-radius:5px; box-sizing: border-box;">
                        </div>
                        <div class="form-group">
                            <label>Lokasi Rak</label>
                            <select name="id_rak" required style="width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 5px;">
                                <option value="">-- Pilih Rak --</option>
                                <?php 
                                $sql_rak = mysqli_query($koneksi, "SELECT * FROM tbl_rak ORDER BY nama_rak ASC");
                                while($rak = mysqli_fetch_array($sql_rak)){ echo "<option value='".$rak['id_rak']."'>".$rak['kode_rak']." - ".$rak['nama_rak']."</option>"; }
                                ?>
                            </select>
                        </div>
                    </div>
                    <div class="form-group" style="margin-bottom: 15px;">
                        <label>Cover Buku (Format: JPG/PNG)</label>
                        <input type="file" name="cover" accept="image/*" style="width:100%; padding:10px; border:1px solid #ddd; border-radius:5px; box-sizing: border-box;">
                    </div>
                    <button type="submit" name="simpan" style="background:#667eea; color:white; border:none; padding:12px; width:100%; border-radius:5px; cursor:pointer; font-weight: bold;">Tambah Buku</button>
                </form>
            </div>
        </main>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <script>
function toggleFormBuku() {
    var formBox = document.getElementById("containerFormBuku");
    var btn = document.getElementById("btnToggleBuku");
    
    if (formBox.style.display === "none") {
        formBox.style.display = "block";
        btn.innerHTML = "✖ Tutup Form";
        btn.style.background = "#e74c3c";
        formBox.scrollIntoView({ behavior: 'smooth' });
    } else {
        formBox.style.display = "none";
        btn.innerHTML = "+ Tambah Buku";
        btn.style.background = "#667eea";
    }
}
</script>
    <script>
        // VALIDASI BAHASA INDONESIA
        document.addEventListener("DOMContentLoaded", function() {
            const inputs = document.querySelectorAll('input, select');
            inputs.forEach(input => {
                input.oninvalid = function(e) {
                    e.target.setCustomValidity("");
                    if (!e.target.validity.valid) {
                        if (e.target.name === "isbn") {
                            e.target.setCustomValidity(e.target.value === "" ? "ISBN tidak boleh kosong!" : "ISBN harus 13 digit angka!");
                        } else { e.target.setCustomValidity("Bagian ini wajib diisi!"); }
                    }
                };
                input.oninput = function(e) { 
                    e.target.setCustomValidity(""); 
                    if (e.target.name === "isbn") { e.target.value = e.target.value.replace(/[^0-9]/g, ''); }
                };
            });
        });

        $(document).ready( function () {
            $('#tabelKu').DataTable({
                "language": { "url": "//cdn.datatables.net/plug-ins/1.13.4/i18n/id.json" },
                "dom": '<"top"f>rt<"bottom"ilp><"clear">'
            });
        });

        function bukaModalEdit(id, judul, isbn, id_rak, stok, cover) {
            document.getElementById('edit_id_buku').value = id;
            document.getElementById('edit_judul').value = judul;
            document.getElementById('edit_isbn').value = isbn;
            document.getElementById('edit_rak').value = id_rak;
            document.getElementById('edit_stok').value = stok;
            
            // Preview Image
            var pathCover = cover ? "../cover/" + cover : "../cover/default.jpg";
            document.getElementById('preview_cover').src = pathCover;
            
            document.getElementById('modalEdit').style.display = 'block';
        }

        function tutupModalEdit() { document.getElementById('modalEdit').style.display = 'none'; }
        function konfirmasiHapus(url) {
            Swal.fire({
                title: 'Hapus data buku?',
                text: "Data dan gambar akan dihapus permanen!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#e74c3c',
                confirmButtonText: 'Ya, Hapus!'
            }).then((result) => { if (result.isConfirmed) { window.location.href = url; } });
        }
    </script>
</body>
</html>