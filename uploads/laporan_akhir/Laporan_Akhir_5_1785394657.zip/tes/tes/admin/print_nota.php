<?php
// Menghubungkan ke file koneksi di luar folder admin
include '../koneksi.php';

// Mengambil ID transaksi dari URL link print
$id = isset($_GET['id']) ? $_GET['id'] : 0;

// Query mengambil data transaksi digabung dengan data buku (b.penulis) dan anggota
// CATATAN: Jika nama tabel transaksi Anda bukan 'tbl_transaksi', silakan ganti namanya di bawah ini.
$query = mysqli_query($koneksi, "SELECT t.*, b.judul, b.penulis, a.nama_lengkap 
                                 FROM tbl_transaksi t
                                 JOIN tbl_buku b ON t.id_buku = b.id_buku
                                 JOIN tbl_anggota a ON t.id_anggota = a.id_anggota
                                 WHERE t.id_transaksi = '$id'");

// Jalankan query cadangan jika primary key di tabel Anda bernama 'id_pinjam'
if (mysqli_num_rows($query) == 0) {
    $query = mysqli_query($koneksi, "SELECT t.*, b.judul, b.penulis, a.nama_lengkap 
                                     FROM tbl_transaksi t
                                     JOIN tbl_buku b ON t.id_buku = b.id_buku
                                     JOIN tbl_anggota a ON t.id_anggota = a.id_anggota
                                     WHERE t.id_pinjam = '$id'");
}

$data = mysqli_fetch_array($query);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nota Peminjaman - Litera-Z</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            color: #333;
            background: #fff;
            margin: 30px;
        }
        .cetak-container {
            max-width: 600px;
            margin: 0 auto;
            border: 1px solid #e0e0e0;
            padding: 30px;
            border-radius: 8px;
        }
        .header-nota {
            text-align: center;
            border-bottom: 2px double #5c6bc0;
            padding-bottom: 15px;
            margin-bottom: 25px;
        }
        .header-nota h2 {
            margin: 0;
            color: #5c6bc0;
            letter-spacing: 1px;
        }
        .header-nota p {
            margin: 5px 0 0 0;
            font-size: 13px;
            color: #666;
        }
        .tabel-detail {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 40px;
        }
        .tabel-detail td {
            padding: 12px 10px;
            border-bottom: 1px solid #f0f0f0;
            font-size: 15px;
        }
        .tabel-detail td:first-child {
            font-weight: 600;
            width: 35%;
            color: #555;
        }
        .status-badge {
            padding: 4px 10px;
            background: #fff8e1;
            color: #ffb300;
            border: 1px solid #ffe082;
            border-radius: 4px;
            font-size: 13px;
            font-weight: bold;
        }
        .footer {
            display: flex;
            justify-content: space-between;
            margin-top: 50px;
        }
        .tanda-tangan {
            text-align: center;
            width: 45%;
            font-size: 14px;
        }
        .tanda-tangan p {
            margin-bottom: 70px;
        }
    </style>
</head>
<body>

    <div class="cetak-container">
        <div class="header-nota">
            <h2>LITERA-Z</h2>
            <p>Nota Bukti Peminjaman Buku</p>
        </div>

        <table class="tabel-detail">
            <tr>
                <td>Nama Peminjam</td>
                <td>: <?php echo isset($data['nama_lengkap']) ? $data['nama_lengkap'] : '-'; ?></td>
            </tr>
            <tr>
                <td>Judul Buku</td>
                <td>: <?php echo isset($data['judul']) ? $data['judul'] : '-'; ?></td>
            </tr>
            <tr>
                <td>Penulis Buku</td>
                <td>: <?php echo isset($data['penulis']) ? $data['penulis'] : '-'; ?></td>
            </tr>
            <tr>
                <td>Tanggal Pinjam</td>
                <td>: <?php echo isset($data['tgl_pinjam']) ? $data['tgl_pinjam'] : '-'; ?></td>
            </tr>
            <tr>
                <td>Harus Kembali</td>
                <td>: <?php echo isset($data['harus_kembali']) ? $data['harus_kembali'] : (isset($data['tgl_kembali_seharusnya']) ? $data['tgl_kembali_seharusnya'] : '-'); ?></td>
            </tr>
            <tr>
                <td>Status Transaksi</td>
                <td>: <span class="status-badge"><?php echo isset($data['status']) ? $data['status'] : 'Dipinjam'; ?></span></td>
            </tr>
        </table>

        <div class="footer">
            <div class="tanda-tangan">
                <p>Peminjam,</p>
                <strong><?php echo isset($data['nama_lengkap']) ? $data['nama_lengkap'] : '........................'; ?></strong>
            </div>
            <div class="tanda-tangan">
                <p>Petugas Perpustakaan,</p>
                <strong>( Administrator )</strong>
            </div>
        </div>
    </div>

    <script>
        window.onload = function() {
            window.print();
        }
    </script>
</body>
</html>