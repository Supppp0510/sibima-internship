<?php
session_start();
// 1. Jalur koneksi
include '../koneksi.php';

// 2. Proteksi Halaman
if (!isset($_SESSION['status']) || $_SESSION['status'] != "login" || $_SESSION['role'] != "admin") {
    header("location:../index.php?pesan=belum_login");
    exit();
}
// 3. LOGIKA SIMPAN RAK (Dengan Validasi agar tidak duplikat)
if (isset($_POST['tambah_rak'])) {
    $kode_rak = mysqli_real_escape_string($koneksi, $_POST['kode_rak']);
    $nama_rak = mysqli_real_escape_string($koneksi, $_POST['nama_rak']);

    // Cek apakah kode rak sudah ada
    $cek_kode = mysqli_query($koneksi, "SELECT * FROM tbl_rak WHERE kode_rak = '$kode_rak'");
    
    if (mysqli_num_rows($cek_kode) > 0) {
        // Notifikasi jika kode sudah ada
        echo "<script src='https://cdn.jsdelivr.net/npm/sweetalert2@11'></script>";
        echo "<script>
            setTimeout(function() {
                Swal.fire({
                    title: 'Gagal!',
                    text: 'Kode Rak $kode_rak sudah terdaftar, gunakan kode lain!',
                    icon: 'error'
                });
            }, 100);
        </script>";
    } else {
        $simpan = mysqli_query($koneksi, "INSERT INTO tbl_rak (kode_rak, nama_rak) VALUES ('$kode_rak', '$nama_rak')");
        if ($simpan) {
            echo "<script src='https://cdn.jsdelivr.net/npm/sweetalert2@11'></script>";
            echo "<script>
                setTimeout(function() {
                    Swal.fire({
                        title: 'Berhasil!',
                        text: 'Rak baru telah ditambahkan',
                        icon: 'success',
                        timer: 2000,
                        showConfirmButton: false
                    }).then(function() { window.location = 'rak.php'; });
                }, 100);
            </script>";
        }
    }
}

// --- LOGIKA UPDATE RAK ---
if (isset($_POST['update_rak'])) {
    $id_rak   = $_POST['id_rak'];
    $kode_rak = mysqli_real_escape_string($koneksi, $_POST['kode_rak']);
    $nama_rak = mysqli_real_escape_string($koneksi, $_POST['nama_rak']);

    // Cek apakah kode rak sudah digunakan oleh ID lain
    $cek_kode_lain = mysqli_query($koneksi, "SELECT * FROM tbl_rak WHERE kode_rak = '$kode_rak' AND id_rak != '$id_rak'");

    if (mysqli_num_rows($cek_kode_lain) > 0) {
        echo "<script src='https://cdn.jsdelivr.net/npm/sweetalert2@11'></script>";
        echo "<script>
            setTimeout(function() {
                Swal.fire({
                    title: 'Gagal Update!',
                    text: 'Kode Rak $kode_rak sudah digunakan oleh rak lain!',
                    icon: 'warning'
                });
            }, 100);
        </script>";
    } else {
        $update = mysqli_query($koneksi, "UPDATE tbl_rak SET kode_rak='$kode_rak', nama_rak='$nama_rak' WHERE id_rak='$id_rak'");
        if ($update) {
            echo "<script src='https://cdn.jsdelivr.net/npm/sweetalert2@11'></script>";
            echo "<script>
                setTimeout(function() {
                    Swal.fire({
                        title: 'Berhasil!',
                        text: 'Data rak telah diperbarui',
                        icon: 'success',
                        timer: 2000,
                        showConfirmButton: false
                    }).then(function() { window.location = 'rak.php'; });
                }, 100);
            </script>";
        }
    }
}

// --- LOGIKA HAPUS RAK ---
if (isset($_GET['aksi']) && $_GET['aksi'] == 'hapus_rak') {
    $id = $_GET['id'];
    
    // Validasi: Cek apakah rak sedang digunakan di tabel buku
    $cek_buku = mysqli_query($koneksi, "SELECT * FROM tbl_buku WHERE id_rak='$id'");
    
    if (mysqli_num_rows($cek_buku) > 0) {
        echo "<script src='https://cdn.jsdelivr.net/npm/sweetalert2@11'></script>";
        echo "<script>
            setTimeout(function() {
                Swal.fire({
                    title: 'Gagal!',
                    text: 'Rak tidak bisa dihapus karena masih berisi buku!',
                    icon: 'error'
                }).then(function() { window.location = 'rak.php'; });
            }, 100);
        </script>";
    } else {
        $hapus = mysqli_query($koneksi, "DELETE FROM tbl_rak WHERE id_rak='$id'");
        if ($hapus) {
            echo "<script src='https://cdn.jsdelivr.net/npm/sweetalert2@11'></script>";
            echo "<script>
                setTimeout(function() {
                    Swal.fire({
                        title: 'Terhapus!',
                        text: 'Data rak berhasil dihapus',
                        icon: 'success',
                        timer: 2000,
                        showConfirmButton: false
                    }).then(function() { window.location = 'rak.php'; });
                }, 100);
            </script>";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manajemen Lokasi Rak - Litera-Z</title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css">
    <style>
        .rak-container { width: 100%; }
        .content-box { background:white; padding:20px; border-radius:10px; box-shadow:0 2px 5px rgba(0,0,0,0.1); margin-bottom: 20px;}
        .dataTables_wrapper .bottom { display: flex; justify-content: space-between; align-items: center; margin-top: 15px; padding-top: 10px; border-top: 1px solid #eee; }
        @media (max-width: 768px) { .grid-rak { grid-template-columns: 1fr; } }
    </style>
</head>
<body>
     <div id="modalEditRak" style="display: none; position: fixed; z-index: 9999; left: 0; top: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5);"> 
    <div style="background: white; margin: 10% auto; padding: 20px; width: 400px; border-radius: 8px; box-shadow: 0 4px 15px rgba(0,0,0,0.2);">
        <h3 style="margin-top:0;">Edit Lokasi Rak</h3><hr>
        <form action="" method="POST">
            <input type="hidden" name="id_rak" id="edit_id_rak">
            <div style="margin-bottom: 15px;">
                <label style="display:block; margin-bottom:5px;">Kode Rak</label>
                <input type="text" name="kode_rak" id="edit_kode_rak" required style="width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 4px; box-sizing: border-box;">
            </div>
            <div style="margin-bottom: 20px;">
                <label style="display:block; margin-bottom:5px;">Nama / Lokasi Rak</label>
                <input type="text" name="nama_rak" id="edit_nama_rak" required style="width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 4px; box-sizing: border-box;">
            </div>
            <div style="display: flex; gap: 10px;">
                <button type="submit" name="update_rak" style="background:#f1c40f; color:white; border:none; padding:10px 20px; border-radius:4px; cursor:pointer; flex:1; font-weight:bold;">Update Data</button>
                <button type="button" onclick="tutupModalEditRak()" style="background:#95a5a6; color:white; border:none; padding:10px 20px; border-radius:4px; cursor:pointer; flex:1;">Batal</button>
            </div>
        </form>
    </div>
</div>

    <div class="dashboard-container">
        <aside class="sidebar">
            <div class="sidebar-header">
            <img src="../img/logo1.png" alt="Logo Litera-Z" class="sidebar-logo"></div>
            <ul class="sidebar-menu">
                <li><a href="index.php">Dashboard</a></li>
                <li><a href="buku.php">Data Buku</a></li> 
                <li><a href="rak.php" class="active">Rak Buku</a></li> 
                <li><a href="anggota.php">Data Anggota</a></li>
                <li><a href="transaksi.php">Peminjaman</a></li>
                <li><a href="laporan.php">Laporan</a></li>
                <li><a href="pengaturan.php">Pengaturan</a></li> 
            <li style="margin-top: 15px; border-top: 1px solid rgba(255,255,255,0.1); padding-top: 10px;">
        <a href="../logout.php" onclick="return confirm('Apakah anda yakin ingin keluar?')" style="color: #ff7675; font-weight: bold;">Logout</a>
    </li>
</ul>
            </ul>
        </aside>

        <main class="main-content">
            <div class="content-header" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                <h1>Manajemen Lokasi Rak</h1>
            </div>

            <div class="content-box">
                    <h3 style="margin-bottom: 1rem;">Daftar Lokasi Rak</h3>
                    <button type="button" id="btnToggleRak" onclick="toggleFormRak()" style="background: #667eea; color: white; border: none; padding: 10px 18px; border-radius: 6px; cursor: pointer; font-weight: bold; font-family: inherit; font-size: 13px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); transition: all 0.3s ease;">+ Tambah Rak
                    </button>
                    <table id="tabelRak" class="display" style="width:100%">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Kode Rak</th>
                                <th>Nama Rak / Lokasi</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $no_rak = 1;
                            $list_r = mysqli_query($koneksi, "SELECT * FROM tbl_rak ORDER BY kode_rak ASC");
                            while($lr = mysqli_fetch_array($list_r)){
                            ?>
                            <tr>
                                <td><?php echo $no_rak++; ?></td>
                                <td><span style="font-weight: bold; color: #667eea;"><?php echo $lr['kode_rak']; ?></span></td>
                                <td><?php echo $lr['nama_rak']; ?></td>
                                <td><button onclick="bukaModalEditRak('<?php echo $lr['id_rak']; ?>', '<?php echo $lr['kode_rak']; ?>', '<?php echo $lr['nama_rak']; ?>')" 
                                    style="background:#f1c40f; color:white; border:none; padding:5px 10px; border-radius:4px; cursor:pointer;">Edit</button>
                                    <a href="rak.php?aksi=hapus_rak&id=<?php echo $lr['id_rak']; ?>" 
                                       style="background:#e74c3c; padding:6px 12px; color:white; text-decoration:none; border-radius:4px; font-size:0.75rem;" 
                                       onclick="konfirmasiHapus(event, this.href)">Hapus</a>
                                </td>
                            </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>

                <div id="containerFormRak" class="content-box" style="display: none; margin-bottom: 2rem; background:white; padding:20px; border-radius:10px; box-shadow:0 2px 5px rgba(0,0,0,0.1);">
                    <h3>Buat Rak Baru</h3><br>
                    <form action="" method="POST">
                        <label style="font-size: 0.85rem; color: #666;">Kode Rak</label>
                        <input type="text" name="kode_rak" placeholder="Contoh: R01" required style="width:100%; padding:10px; border:1px solid #ddd; border-radius:5px; margin-bottom:15px; margin-top:5px;">
                        
                        <label style="font-size: 0.85rem; color: #666;">Nama / Lokasi Rak</label>
                        <input type="text" name="nama_rak" placeholder="Contoh: Novel / Fiksi" required style="width:100%; padding:10px; border:1px solid #ddd; border-radius:5px; margin-bottom:15px; margin-top:5px;">
                        
                        <button type="submit" name="tambah_rak" style="background:#667eea; color:white; border:none; padding:12px; width:100%; border-radius:5px; cursor:pointer; font-weight: bold; font-size: 1rem;">Tambah Rak</button>
                    </form>
                </div>
            </div>
        </main>
    </div>

   

    <!-- SCRIPTS -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <script>
function toggleFormRak() {
    var formBox = document.getElementById("containerFormRak");
    var btn = document.getElementById("btnToggleRak");
    
    if (formBox.style.display === "none") {
        formBox.style.display = "block";
        btn.innerHTML = "✖ Tutup Form";
        btn.style.background = "#e74c3c";
        formBox.scrollIntoView({ behavior: 'smooth' });
    } else {
        formBox.style.display = "none";
        btn.innerHTML = "+ Tambah Rak";
        btn.style.background = "#667eea";
    }
}
</script>
    <script>
        $(document).ready( function () {
        $('#tabelRak').DataTable({"language": {"url": "//cdn.datatables.net/plug-ins/1.13.4/i18n/id.json"},
        "dom": '<"top"f>rt<"bottom"ilp><"clear">'});});

        function bukaModalEditRak(id, kode, nama) {
        document.getElementById('edit_id_rak').value = id;
        document.getElementById('edit_kode_rak').value = kode;
        document.getElementById('edit_nama_rak').value = nama;
        document.getElementById('modalEditRak').style.display = 'block';
         }
    function tutupModalEditRak() {
        document.getElementById('modalEditRak').style.display = 'none';
        }

        function konfirmasiHapus(event, url) {
            event.preventDefault(); 
            Swal.fire({
                title: 'Hapus data rak?',
                text: "Data tidak bisa dihapus jika masih ada buku di dalam rak ini!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#e74c3c',
                cancelButtonColor: '#6c757d',
                confirmButtonText: 'Ya, Hapus',
                cancelButtonText: 'Batal'
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = url; 
                }
            })
        }
    </script>
</body>
</html>