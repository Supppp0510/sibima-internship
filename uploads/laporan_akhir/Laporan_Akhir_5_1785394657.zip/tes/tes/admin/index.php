<?php
session_start();
// Jalur koneksi naik satu tingkat karena file ini ada di dalam folder admin
include '../koneksi.php'; 

// Mengatur zona waktu ke Indonesia/Jakarta
date_default_timezone_set('Asia/Jakarta');

// 1. CEK LOGIN & ROLE
if (!isset($_SESSION['status']) || $_SESSION['status'] != "login" || $_SESSION['role'] != "admin") {
    header("location:../index.php?pesan=belum_login");
    exit();
}

// DATA UNTUK GRAFIK (Perbaikan nama kolom dari status_pinjam menjadi status)
$grafik_pinjam = mysqli_query($koneksi, "SELECT COUNT(*) as total FROM tbl_transaksi WHERE status='Dipinjam'");
$hasil_pinjam = mysqli_fetch_assoc($grafik_pinjam);
$total_pinjam = $hasil_pinjam['total'] ?? 0;

$grafik_kembali = mysqli_query($koneksi, "SELECT COUNT(*) as total FROM tbl_transaksi WHERE status='Dikembalikan'");
$hasil_kembali = mysqli_fetch_assoc($grafik_kembali);
$total_kembali = $hasil_kembali['total'] ?? 0;

// Tambahan: Mengambil data status 'Telat' yang ada di enum database Anda
$grafik_telat = mysqli_query($koneksi, "SELECT COUNT(*) as total FROM tbl_transaksi WHERE status='Telat'");
$hasil_telat = mysqli_fetch_assoc($grafik_telat);
$total_telat = $hasil_telat['total'] ?? 0;

// 2. HITUNG DATA DARI DATABASE
$query_buku = mysqli_query($koneksi, "SELECT COUNT(*) as jumlah FROM tbl_buku");
$data_buku = mysqli_fetch_assoc($query_buku);
$total_buku = $data_buku['jumlah'] ?? 0;

$query_anggota = mysqli_query($koneksi, "SELECT COUNT(*) as jumlah FROM tbl_anggota");
$data_anggota = mysqli_fetch_assoc($query_anggota);
$total_anggota = $data_anggota['jumlah'] ?? 0;

$query_transaksi = mysqli_query($koneksi, "SELECT COUNT(*) as jumlah FROM tbl_transaksi");
$data_transaksi = mysqli_fetch_assoc($query_transaksi);
$total_transaksi = $data_transaksi['jumlah'] ?? 0;
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Admin - Litera-Z</title>
    <link rel="stylesheet" href="../css/style.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
    <div class="dashboard-container">
        <aside class="sidebar">
            <div class="sidebar-header">
                <img src="../img/logo1.png" alt="Logo Litera-Z" class="sidebar-logo">
            </div>
            <ul class="sidebar-menu">
                <li><a href="index.php" class="active">Dashboard</a></li>
                <li><a href="buku.php">Data Buku</a></li>
                <li><a href="rak.php">Rak Buku</a></li>
                <li><a href="anggota.php">Data Anggota</a></li>
                <li><a href="transaksi.php">Peminjaman</a></li>
                <li><a href="laporan.php">Laporan</a></li>
                <li><a href="pengaturan.php">Pengaturan</a></li>
            <li style="margin-top: 15px; border-top: 1px solid rgba(255,255,255,0.1); padding-top: 10px;">
        <a href="../logout.php" onclick="return confirm('Apakah anda yakin ingin keluar?')" style="color: #ff7675; font-weight: bold;">Logout</a>
    </li>
</ul>
       

        <main class="main-content">
            <div class="content-header">
                <h1>Dashboard Admin</h1>
            </div>

            <div class="welcome-banner" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 25px; border-radius: 15px; margin-bottom: 30px; box-shadow: 0 10px 20px rgba(118, 75, 162, 0.2);">
                <div style="display: flex; align-items: center; justify-content: space-between;">
                    <div>
                        <h2 style="margin: 0; font-size: 1.8rem;">Selamat Datang, <?php echo htmlspecialchars($_SESSION['username']); ?>!</h2>
                        <p style="margin: 10px 0 0 0; font-size: 1rem; opacity: 0.9;">Anda masuk sebagai <b>Admin</b> Perpustakaan Digital Litera-Z.</p>
                    </div>
                    <div style="text-align: right;">
                        <h3 id="clock" style="margin: 0; font-size: 1.5rem;">00:00:00</h3>
                        <p style="margin: 0;"><?php echo date('l, d F Y'); ?></p>
                    </div>
                </div>
            </div>

            <div class="stats-grid" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin-bottom: 30px;">
                <div class="stat-card" style="background: white; padding: 20px; border-radius: 10px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); text-align: center;">
                    <h3 style="color: #666; font-size: 0.9rem; margin-bottom: 10px;">Total Buku</h3>
                    <div class="stat-value" style="font-size: 2rem; font-weight: bold; color: #764ba2;"><?php echo $total_buku; ?></div>
                </div>
                <div class="stat-card" style="background: white; padding: 20px; border-radius: 10px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); text-align: center;">
                    <h3 style="color: #666; font-size: 0.9rem; margin-bottom: 10px;">Total Anggota</h3>
                    <div class="stat-value" style="font-size: 2rem; font-weight: bold; color: #764ba2;"><?php echo $total_anggota; ?></div>
                </div>
                <div class="stat-card" style="background: white; padding: 20px; border-radius: 10px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); text-align: center;">
                    <h3 style="color: #666; font-size: 0.9rem; margin-bottom: 10px;">Total Transaksi</h3>
                    <div class="stat-value" style="font-size: 2rem; font-weight: bold; color: #764ba2;"><?php echo $total_transaksi; ?></div>
                </div>
            </div>

            <div class="content-box" style="background: white; padding: 30px; border-radius: 15px; box-shadow: 0 4px 6px rgba(0,0,0,0.05);">
                <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap;">
                    <div style="flex: 1; min-width: 300px; padding-right: 20px;">
                        <h2 style="font-size: 1.8rem; font-weight: 800; margin-bottom: 10px; color: #2c3e50;">Statistik Perpustakaan</h2>
                        <p style="color: #666; margin-bottom: 15px;">Aktivitas peminjaman buku secara real-time.</p>
                        <a href="transaksi.php" class="btn btn-primary" style="background: #667eea; color: white; padding: 10px 20px; border-radius: 5px; text-decoration: none; display: inline-block;">Kelola Peminjaman</a>
                    </div>
                    <div style="flex: 1; min-width: 300px; max-width: 400px;">
                        <canvas id="transaksiChart"></canvas>
                    </div>
                </div>
            </div>
        </main>
    </div>

    <script>
        function updateClock() {
            const now = new Date();
            let h = now.getHours();
            let m = now.getMinutes();
            let s = now.getSeconds();
            
            h = h < 10 ? "0" + h : h;
            m = m < 10 ? "0" + m : m;
            s = s < 10 ? "0" + s : s;
            
            const timeString = h + ":" + m + ":" + s;
            document.getElementById('clock').innerText = timeString;
        }
        setInterval(updateClock, 1000);
        updateClock();
    </script>

    <script>
        const ctx = document.getElementById('transaksiChart').getContext('2d');
        new Chart(ctx, {
            type: 'pie',
            data: {
                labels: ['Sedang Dipinjam', 'Sudah Dikembalikan', 'Terlambat/Telat'],
                datasets: [{
                    data: [<?php echo $total_pinjam; ?>, <?php echo $total_kembali; ?>, <?php echo $total_telat; ?>],
                    backgroundColor: ['#f1c40f', '#2ecc71', '#e74c3c'],
                    borderWidth: 2
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: { position: 'bottom' }
                }
            }
        });
    </script>
</body>
</html>