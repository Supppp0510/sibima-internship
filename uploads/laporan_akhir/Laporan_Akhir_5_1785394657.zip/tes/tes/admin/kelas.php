<?php
session_start();
// 1. Jalur koneksi naik satu tingkat ke luar folder admin
include '../koneksi.php';

// 2. Proteksi Halaman: Cek login dan role admin
if (!isset($_SESSION['status']) || $_SESSION['status'] != "login" || $_SESSION['role'] != "admin") {
    header("location:../index.php?pesan=belum_login");
    exit();
}

// 3. SIMPAN DATA KELAS
if (isset($_POST['simpan'])) {
    $nama_kelas = $_POST['nama_kelas'];
    $tingkat    = $_POST['tingkat'];
    $jurusan    = $_POST['jurusan'];
    $simpan = mysqli_query($koneksi, "INSERT INTO tbl_kelas (nama_kelas, tingkat, jurusan) VALUES ('$nama_kelas', '$tingkat', '$jurusan')");
    if ($simpan) {
        echo "<script>alert('Data Kelas Berhasil Disimpan!'); window.location='kelas.php';</script>";
    } else {
        echo "<script>alert('Gagal Menyimpan Data!');</script>";
    }
}

// 4. HAPUS DATA KELAS
if (isset($_GET['aksi']) && $_GET['aksi'] == 'hapus') {
    $id = $_GET['id'];
    $hapus = mysqli_query($koneksi, "DELETE FROM tbl_kelas WHERE id_kelas='$id'");
    if ($hapus) {
        echo "<script>alert('Data Berhasil Dihapus!'); window.location='kelas.php';</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kelas - Admin Litera-Z</title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css">
    <style>
        .dataTables_wrapper { margin-top: 20px; font-family: sans-serif; font-size: 0.9rem; }
        .dataTables_length select { padding: 5px; }
        .dataTables_filter input { padding: 5px; border: 1px solid #ddd; border-radius: 4px; }
        table.dataTable thead th { background-color: #f8f9fa; color: #333; }
    </style>
</head>
<body>
    <div class="dashboard-container">
        <aside class="sidebar">
            <div class="sidebar-header">
                <h2>Litera-Z</h2>
            </div>
            <ul class="sidebar-menu">
                <li><a href="index.php">Dashboard</a></li>
                <li><a href="kelas.php" class="active">Kelas</a></li>
                <li><a href="buku.php">Data Buku</a></li>
                <li><a href="anggota.php">Data Anggota</a></li>
                <li><a href="rak.php">Rak Buku</a></li>
                <li><a href="transaksi.php">Peminjaman</a></li>
                <li><a href="laporan.php">Laporan</a></li>
                <li><a href="pengaturan.php">Pengaturan</a></li>
            </ul>
        </aside>

        <main class="main-content">
            <div class="content-header" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 25px; border-radius: 15px; margin-bottom: 30px; color: white; display: flex; justify-content: space-between; align-items: center; box-shadow: 0 10px 20px rgba(118, 75, 162, 0.2);">
                <h1 style="color: white; margin: 0; font-size: 1.8rem;">Data Kelas</h1>
                <a href="../logout.php" class="btn btn-logout" style="background:rgba(255,255,255,0.2); border:1px solid white; color:white; padding:8px 15px; border-radius:5px; text-decoration:none;">Logout</a>
            </div>

            <div class="content-box" style="margin-bottom: 2rem; background:white; padding:20px; border-radius:10px; box-shadow:0 2px 5px rgba(0,0,0,0.1);">
                <h2 style="margin-bottom: 1rem;">Tambah Kelas Baru</h2>
                <form action="" method="POST" style="display: flex; gap: 15px; align-items: flex-end; flex-wrap: wrap;">
                    <div class="form-group">
                        <label style="display:block; margin-bottom:5px;">Nama Kelas</label>
                        <input type="text" name="nama_kelas" required style="padding:10px; border:1px solid #ddd; border-radius:5px;">
                    </div>
                    <div class="form-group">
                        <label style="display:block; margin-bottom:5px;">Tingkat</label>
                        <input type="text" name="tingkat" placeholder="X, XI, XII" required style="padding:10px; border:1px solid #ddd; border-radius:5px;">
                    </div>
                    <div class="form-group">
                        <label style="display:block; margin-bottom:5px;">Jurusan</label>
                        <input type="text" name="jurusan" placeholder="RPL, TKJ" required style="padding:10px; border:1px solid #ddd; border-radius:5px;">
                    </div>
                    <button type="submit" name="simpan" class="btn btn-primary" style="background:#667eea; color:white; border:none; padding:11px 25px; border-radius:5px; cursor:pointer; font-weight: bold;">Simpan</button>
                </form>
            </div>

            <div class="content-box" style="background:white; padding:20px; border-radius:10px; box-shadow:0 2px 5px rgba(0,0,0,0.1);">
                <h2 style="margin-bottom: 1rem;">Daftar Kelas</h2>
                <table id="tabelKelas" class="display" style="width:100%">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Nama Kelas</th>
                            <th>Tingkat</th>
                            <th>Jurusan</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $no = 1;
                        $tampil = mysqli_query($koneksi, "SELECT * FROM tbl_kelas ORDER BY nama_kelas ASC");
                        while($data = mysqli_fetch_array($tampil)){
                        ?>
                        <tr>
                            <td><?php echo $no++; ?></td>
                            <td><?php echo $data['nama_kelas']; ?></td>
                            <td><?php echo $data['tingkat']; ?></td>
                            <td><?php echo $data['jurusan']; ?></td>
                            <td>
                                <a href="kelas.php?aksi=hapus&id=<?php echo $data['id_kelas']; ?>" 
                                   style="background:#e74c3c; padding:5px 10px; color:white; text-decoration:none; border-radius:4px; font-size:0.8rem;"
                                   onclick="return confirm('Yakin ingin menghapus kelas ini?')">Hapus</a>
                            </td>
                        </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </main>
    </div>
    
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
    <script>
        $(document).ready( function () {
            $('#tabelKelas').DataTable({ 
                "language": { "url": "//cdn.datatables.net/plug-ins/1.13.4/i18n/id.json" } 
            });
        });
    </script>
</body>
</html>