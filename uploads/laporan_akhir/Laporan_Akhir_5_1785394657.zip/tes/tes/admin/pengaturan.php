<?php
session_start();
// 1. Jalur koneksi naik satu tingkat ke folder 'tes'
include '../koneksi.php';

// 2. Proteksi Halaman: Cek login dan role admin
if (!isset($_SESSION['status']) || $_SESSION['status'] != "login" || $_SESSION['role'] != "admin") {
    header("location:../index.php?pesan=belum_login");
    exit();
}

$username_sekarang = $_SESSION['username'];

// A. LOGIKA GANTI PASSWORD (INTEGRASI SWEETALERT2)
if (isset($_POST['ubah_password'])) {
    $pass_lama = mysqli_real_escape_string($koneksi, $_POST['pass_lama']);
    $pass_baru = mysqli_real_escape_string($koneksi, $_POST['pass_baru']);
    $pass_konf = mysqli_real_escape_string($koneksi, $_POST['pass_konf']);

    // Cek apakah password lama benar
    $cek = mysqli_query($koneksi, "SELECT * FROM tbl_user WHERE username='$username_sekarang' AND password='$pass_lama'");
    
    if (mysqli_num_rows($cek) > 0) {
        if ($pass_baru == $pass_konf) {
            mysqli_query($koneksi, "UPDATE tbl_user SET password='$pass_baru' WHERE username='$username_sekarang'");
            echo "<script>
                document.addEventListener('DOMContentLoaded', function() {
                    Swal.fire({
                        title: 'Berhasil!',
                        text: 'Password Admin berhasil diubah.',
                        icon: 'success',
                        confirmButtonColor: '#667eea'
                    });
                });
            </script>";
        } else {
            echo "<script>
                document.addEventListener('DOMContentLoaded', function() {
                    Swal.fire({
                        title: 'Gagal!',
                        text: 'Konfirmasi password baru tidak cocok.',
                        icon: 'error',
                        confirmButtonColor: '#e74c3c'
                    });
                });
            </script>";
        }
    } else {
        echo "<script>
            document.addEventListener('DOMContentLoaded', function() {
                Swal.fire({
                    title: 'Error!',
                    text: 'Password lama yang Anda masukkan salah.',
                    icon: 'error',
                    confirmButtonColor: '#e74c3c'
                });
            });
        </script>";
    }
}

// B. LOGIKA SIMPAN PENGATURAN DATA SIRKULASI (DISESUAIKAN DATABASE)
if (isset($_POST['simpan_sistem'])) {
    $denda  = mysqli_real_escape_string($koneksi, $_POST['denda']);
    $durasi = mysqli_real_escape_string($koneksi, $_POST['durasi_pinjam']);

    // Query update disesuaikan dengan kolom database Anda (tanpa nama perpustakaan & alamat)
    $update = mysqli_query($koneksi, "UPDATE tbl_pengaturan SET denda_per_hari='$denda', durasi_pinjam='$durasi' WHERE id=1");
    
    if($update){
        echo "<script>
            document.addEventListener('DOMContentLoaded', function() {
                Swal.fire({
                    title: 'Berhasil Disimpan!',
                    text: 'Aturan denda dan durasi peminjaman berhasil diperbarui.',
                    icon: 'success',
                    confirmButtonColor: '#27ae60'
                }).then(() => {
                    window.location='pengaturan.php';
                });
            });
        </script>";
    }
}

// Ambil Data Pengaturan Saat Ini
$data_pengaturan = mysqli_fetch_assoc(mysqli_query($koneksi, "SELECT * FROM tbl_pengaturan WHERE id=1"));
$query_user = mysqli_query($koneksi, "SELECT password FROM tbl_user WHERE username='$username_sekarang' LIMIT 1");
$data_user  = mysqli_fetch_assoc($query_user);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pengaturan - Admin Litera-Z</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <div class="dashboard-container">
        <aside class="sidebar">
            <div class="sidebar-header">
                <img src="../img/logo1.png" alt="Logo Litera-Z" class="sidebar-logo">
            </div>
            <ul class="sidebar-menu">
                <li><a href="index.php">Dashboard</a></li>
                <li><a href="buku.php">Data Buku</a></li>
                <li><a href="rak.php">Rak Buku</a></li>
                <li><a href="anggota.php">Data Anggota</a></li>
                <li><a href="transaksi.php">Peminjaman</a></li>
                <li><a href="laporan.php">Laporan</a></li>
                <li><a href="pengaturan.php" class="active">Pengaturan</a></li>
            <li style="margin-top: 15px; border-top: 1px solid rgba(255,255,255,0.1); padding-top: 10px;">
        <a href="../logout.php" onclick="return confirm('Apakah anda yakin ingin keluar?')" style="color: #ff7675; font-weight: bold;">Logout</a>
    </li>
</ul>
            </ul>
        </aside>

        <main class="main-content">
            <div class="content-header">
                <h1>Pengaturan</h1>
            </div>

            <div class="content-box" style="margin-bottom: 2rem; background:white; padding:20px; border-radius:10px; box-shadow:0 2px 5px rgba(0,0,0,0.1);">
                <h2 style="margin-bottom: 1rem; color: #333;">Ubah Password Admin</h2>
                <form action="" method="POST">
                    <div style="margin-bottom: 15px;">
                        <label style="display:block; margin-bottom:5px;">Password Saat Ini</label>
                        <input type="text" name="pass_lama" value="<?php echo $data_user['password']; ?>" required style="width:100%; padding:10px; border:1px solid #ddd; border-radius:5px; background-color: #f9f9f9; font-weight: bold; color: #333;">
                    </div>
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin-bottom: 15px;">
                        <div>
                            <label style="display:block; margin-bottom:5px;">Password Baru</label>
                            <input type="password" name="pass_baru" required style="width:100%; padding:10px; border:1px solid #ddd; border-radius:5px;">
                        </div>
                        <div>
                            <label style="display:block; margin-bottom:5px;">Konfirmasi Password Baru</label>
                            <input type="password" name="pass_konf" required style="width:100%; padding:10px; border:1px solid #ddd; border-radius:5px;">
                        </div>
                    </div>
                    <button type="submit" name="ubah_password" class="btn btn-primary" style="background:#667eea; color:white; border:none; padding:10px 20px; border-radius:5px; cursor:pointer; font-weight: bold;">Ubah Password</button>
                </form>
            </div>

            <div class="content-box" style="background:white; padding:20px; border-radius:10px; box-shadow:0 2px 5px rgba(0,0,0,0.1);">
                <h2 style="margin-bottom: 1.5rem; color: #333;">⚙️ Aturan Sirkulasi Buku</h2>
                <form action="" method="POST">
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 20px;">
                        
                        <div>
                            <label style="display:block; margin-bottom:8px; font-weight:bold; color: #555;">Denda Per Hari (Rp)</label>
                            <div style="position: relative; display: flex; align-items: center;">
                                <span style="position: absolute; left: 12px; color: #888; font-weight: bold;">Rp</span>
                                <input type="number" name="denda" value="<?php echo $data_pengaturan['denda_per_hari']; ?>" required style="width:100%; padding:11px 11px 11px 35px; border:1px solid #ddd; border-radius:6px; box-sizing: border-box;">
                            </div>
                            <small style="color:#888; display:block; margin-top:5px;">*Tarif denda keterlambatan per hari untuk tiap buku.</small>
                        </div>
                        
                        <div>
                            <label style="display:block; margin-bottom:8px; font-weight:bold; color: #555;">Batas Waktu Peminjaman (Hari)</label>
                            <div style="position: relative; display: flex; align-items: center;">
                                <input type="number" name="durasi_pinjam" value="<?php echo $data_pengaturan['durasi_pinjam']; ?>" required style="width:100%; padding:11px 45px 11px 12px; border:1px solid #ddd; border-radius:6px; box-sizing: border-box;">
                                <span style="position: absolute; right: 15px; color: #888; font-weight: bold;">Hari</span>
                            </div>
                            <small style="color:#888; display:block; margin-top:5px;">*Menentukan otomatis tanggal jatuh tempo buku.</small>
                        </div>

                    </div>
                    
                    <button type="submit" name="simpan_sistem" class="btn btn-primary" style="background:#667eea; color:white; border:none; padding:12px 25px; border-radius:5px; cursor:pointer; font-weight: bold; width:100%;">Simpan Pengaturan Aturan</button>
                </form>
            </div>
        </main>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</body>
</html>