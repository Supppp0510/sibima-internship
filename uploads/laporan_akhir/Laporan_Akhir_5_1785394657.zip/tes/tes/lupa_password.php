<?php
include 'koneksi.php';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reset Password - Litera-Z</title>
    <link rel="stylesheet" href="css/style.css">
    <style>
        /* Tambahan sedikit agar box tetap rapi di tengah */
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .login-box {
            background: white;
            padding: 40px;
            border-radius: 15px;
            box-shadow: 0 10px 25px rgba(0,0,0,0.2);
            width: 100%;
            max-width: 400px;
        }
        .login-header img {
            max-width: 150px;
            margin-bottom: 20px;
        }
        .btn-reset {
            width: 100%;
            padding: 12px;
            background: #667eea;
            color: white;
            border: none;
            border-radius: 8px;
            font-weight: bold;
            cursor: pointer;
            margin-top: 10px;
        }
        .btn-reset:hover {
            background: #764ba2;
        }
        .back-link {
            display: block;
            margin-top: 20px;
            text-align: center;
            color: #667eea;
            text-decoration: none;
            font-size: 0.9rem;
        }
    </style>
</head>
<body>

    <div class="login-box">
        <div class="login-header" style="text-align: center;">
            <img src="img/litera-Z.png" alt="Litera-Z Logo">
            <h2 style="color: #333; margin-top: 0;">Reset Password</h2>
            <p style="color: #777; font-size: 0.85rem; margin-bottom: 25px;">Masukkan username Anda untuk memperbarui password.</p>
        </div>

        <form action="" method="POST">
            <div class="form-group" style="margin-bottom: 15px;">
                <label style="display: block; margin-bottom: 5px; color: #555;">Username</label>
                <input type="text" name="username" required style="width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 5px; box-sizing: border-box;">
            </div>
            <div class="form-group" style="margin-bottom: 20px;">
                <label style="display: block; margin-bottom: 5px; color: #555;">Password Baru</label>
                <input type="password" name="password_baru" required style="width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 5px; box-sizing: border-box;">
            </div>
            <button type="submit" name="reset" class="btn-reset">Update Password</button>
        </form>

        <?php
        if(isset($_POST['reset'])){
            $user = mysqli_real_escape_string($koneksi, $_POST['username']);
            $pass = mysqli_real_escape_string($koneksi, $_POST['password_baru']);

            $cek = mysqli_query($koneksi, "SELECT * FROM tbl_user WHERE username='$user'");
            if(mysqli_num_rows($cek) > 0){
                $update = mysqli_query($koneksi, "UPDATE tbl_user SET password='$pass' WHERE username='$user'");
                if($update){
                    echo "<div style='color: green; text-align: center; margin-top: 15px; font-weight: bold;'>Password berhasil diperbarui!</div>";
                }
            } else {
                echo "<div style='color: red; text-align: center; margin-top: 15px;'>Username tidak ditemukan!</div>";
            }
        }
        ?>

        <a href="index.php" class="back-link">← Kembali ke Login</a>
    </div>

</body>
</html>