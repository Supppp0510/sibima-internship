# 📘 Product Requirements Document (PRD)
## Perpustakaan Digital - MVP

---

## 🧩 1. Ringkasan Produk
Perpustakaan Digital adalah aplikasi berbasis web sederhana untuk membantu pengelolaan data perpustakaan sekolah atau institusi kecil.  
MVP (Minimum Viable Product) ini berfokus pada tampilan antarmuka (UI) dan interaksi dasar menggunakan **HTML, CSS, dan JavaScript** tanpa backend.

---

## 🎯 2. Tujuan Produk
- Menyediakan antarmuka web untuk mengelola data buku, anggota, dan transaksi.
- Memberikan gambaran awal sistem informasi perpustakaan secara interaktif.
- Menjadi dasar untuk pengembangan lebih lanjut menggunakan backend (misalnya Django, Laravel, atau Node.js).

---

## 👥 3. Peran Pengguna
### 1. Admin
- Login ke sistem
- Mengelola data kelas, buku, dan anggota
- Melakukan transaksi peminjaman/pengembalian
- Melihat laporan singkat
- Mengatur konfigurasi dasar sistem

---

## 🖥️ 4. Lingkup Fitur MVP

| Modul | Deskripsi | Status |
|--------|------------|--------|
| **Login** | Form login sederhana (username: `admin`, password: `1234`) | ✅ |
| **Dashboard** | Ringkasan data (total buku, anggota, transaksi) | ✅ |
| **Kelas** | Tampilan daftar kelas (dummy data) | 🟡 |
| **Data Buku** | CRUD sederhana (tambah, hapus) dengan tabel | ✅ |
| **Data Anggota** | CRUD sederhana (dummy data) | 🟡 |
| **Transaksi** | Simulasi peminjaman & pengembalian | 🟡 |
| **Laporan** | Tampilan data dummy laporan peminjaman | 🟡 |
| **Pengaturan** | Dummy page untuk konfigurasi sistem | 🟡 |
| **Logout** | Menghapus sesi login (localStorage) | ✅ |

---

## 🧱 5. Struktur Folder
```
digital-library/
│
├── index.php          → halaman login
├── dashboard.php      → halaman utama
├── kelas.php          → data kelas
├── buku.php           → data buku
├── anggota.php        → data anggota
├── transaksi.php      → transaksi
├── laporan.php        → laporan
├── pengaturan.php     → pengaturan
│
├── css/
│   └── style.css       → file gaya utama
│
└── js/
    └── main.js         → logika dasar aplikasi
```

---

## 🧠 6. Alur Pengguna

1. **Login**
   - Pengguna masuk melalui `index.php`
   - Jika username & password cocok, diarahkan ke `dashboard.php`
   - Jika salah, tampilkan pesan kesalahan

2. **Dashboard**
   - Menampilkan statistik dummy: jumlah buku, anggota, transaksi

3. **Navigasi Sidebar**
   - Pengguna berpindah antar halaman (kelas, buku, anggota, transaksi, laporan, pengaturan)

4. **Data Buku**
   - Pengguna dapat melihat tabel buku
   - Dapat menambah atau menghapus data buku
   - Data sementara disimpan di JavaScript memory

5. **Logout**
   - Menghapus status login (localStorage) dan kembali ke halaman login

---

## 🧰 7. Teknologi yang Digunakan
- **HTML5** untuk struktur halaman  
- **CSS3** untuk styling dasar (tanpa framework)  
- **Vanilla JavaScript (ES6)** untuk logika sederhana  
- **LocalStorage (opsional)** untuk simulasi penyimpanan data sementara  

---

## 🎨 8. Desain & UX
- Tampilan clean dan modern, dominasi warna biru-abu (mirip dashboard admin)
- Sidebar navigasi tetap di sisi kiri
- Konten utama di kanan
- Desain responsif sederhana (fit ke laptop & tablet)

---

## 📊 9. Metrik Keberhasilan (Success Criteria)
- [x] Pengguna dapat login dan logout tanpa error
- [x] Navigasi antar halaman berfungsi
- [x] CRUD sederhana untuk buku berjalan
- [x] Antarmuka dapat diakses melalui browser lokal
- [x] UI konsisten di seluruh halaman

---

## 🚀 10. Roadmap Pengembangan Lanjutan
| Fase | Fitur | Deskripsi |
|------|--------|-----------|
| **V1.0 (MVP)** | Login, Dashboard, CRUD Buku | Sudah selesai |
| **V1.1** | CRUD Anggota, Kelas, Laporan | Menyimpan ke LocalStorage |
| **V2.0** | Integrasi Backend | Gunakan API / Database |
| **V2.1** | Role multi-user (Admin, Petugas, Siswa) | Sistem autentikasi lengkap |
| **V3.0** | Laporan otomatis & statistik grafik | Integrasi Chart.js, ekspor PDF |

---

## 🧾 11. Catatan Tambahan
- Aplikasi berjalan sepenuhnya di sisi client.
- Semua data masih dummy (tidak persistent).
- Dapat dijalankan langsung dengan membuka file HTML di browser.
- Desain dan kode siap diintegrasikan ke backend di tahap berikutnya.

---

📅 **Terakhir Diperbarui:** 29 Oktober 2025  
📄 **Versi:** 1.0 (MVP)
