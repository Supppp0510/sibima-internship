<?php 
session_start();
include 'koneksi.php';

// Ambil data dari form login
// Menggunakan mysqli_real_escape_string untuk mencegah SQL Injection
$username = mysqli_real_escape_string($koneksi, $_POST['username']);
$password = mysqli_real_escape_string($koneksi, $_POST['password']);

// Cek data ke database
$login = mysqli_query($koneksi, "SELECT * FROM tbl_user WHERE username='$username' AND password='$password'");
$cek = mysqli_num_rows($login);

if($cek > 0){
    $data = mysqli_fetch_assoc($login);
    
    // Set session langsung dari data database
    $_SESSION['username']     = $username;
    $_SESSION['nama_lengkap'] = $data['nama_lengkap'];
    $_SESSION['status']       = "login";
    $_SESSION['role']         = $data['role'];

    // Arahkan otomatis berdasarkan role yang tersimpan di database
    if($data['role'] == "admin"){
        header("location:admin/index.php");
    } else if($data['role'] == "user"){
        header("location:user/index.php");
    } else {
        // Jika ada role lain (misal: petugas), arahkan ke foldernya
        header("location:user/index.php");
    }
    exit();

} else {
    // Jika username atau password salah, kembali ke login.php dengan pesan gagal
    header("location:login.php?pesan=gagal");
    exit();
}
?>