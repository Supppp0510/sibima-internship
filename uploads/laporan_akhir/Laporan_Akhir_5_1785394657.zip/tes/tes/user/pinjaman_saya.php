<?php
session_start();
include '../koneksi.php';

// Proteksi user
if ($_SESSION['role'] != "user") {
    header("location:../index.php");
}

$user_aktif = $_SESSION['username'];
?>

<div class="content-box">
    <h2>Buku yang Saya Pinjam</h2>
    <table border="1" style="width:100%; border-collapse: collapse;">
        <thead>
            <tr>
                <th>Judul Buku</th>
                <th>Tanggal Pinjam</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
            <?php
            // Query ini menyambungkan transaksi dengan buku berdasarkan username login
            $my = mysqli_query($koneksi, "SELECT * FROM tbl_transaksi 
                                          JOIN tbl_buku ON tbl_transaksi.id_buku = tbl_buku.id_buku 
                                          JOIN tbl_user ON tbl_transaksi.id_user = tbl_user.id_user
                                          WHERE tbl_user.username = '$user_aktif'");
            
            while($row = mysqli_fetch_array($my)){
            ?>
            <tr>
                <td><?php echo $row['judul']; ?></td>
                <td><?php echo $row['tanggal_pinjam']; ?></td>
                <td><?php echo $row['status_pinjam']; ?></td>
            </tr>
            <?php } ?>
        </tbody>
    </table>
</div>