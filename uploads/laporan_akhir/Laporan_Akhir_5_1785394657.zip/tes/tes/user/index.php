<?php
session_start();
include '../koneksi.php';

// 1. Proteksi & Ambil Data Session dengan pengaman (isset)
if (!isset($_SESSION['status']) || $_SESSION['status'] != "login") {
    header("location:../index.php?pesan=belum_login");
    exit();
}

// Gunakan ?? untuk mencegah error "Undefined array key" jika session kosong
$nis_user  = $_SESSION['username'] ?? '';
$nama_user = $_SESSION['nama_lengkap'] ?? 'Siswa'; 

// 2. LOGIKA PROSES PINJAM (AJAX POST)
if (isset($_POST['id_buku_pinjam'])) {
    $id_buku     = mysqli_real_escape_string($koneksi, $_POST['id_buku_pinjam']);
    $tgl_kembali = mysqli_real_escape_string($koneksi, $_POST['tgl_estimasi']); 
    $tgl_pinjam  = date('Y-m-d');
    
    // Ambil id_anggota berdasarkan NIS
    $cari_mhs    = mysqli_query($koneksi, "SELECT id_anggota FROM tbl_anggota WHERE nis='$nis_user'");
    $data_mhs    = mysqli_fetch_array($cari_mhs);
    $id_anggota  = $data_mhs['id_anggota'] ?? 0;

    // Pastikan kolom-kolom ini sudah dibuat di database (Langkah 1 di atas)
    $query = "INSERT INTO tbl_transaksi (id_buku, id_anggota, nis, tgl_pinjam, tgl_kembali, status) 
              VALUES ('$id_buku', '$id_anggota', '$nis_user', '$tgl_pinjam', '$tgl_kembali', 'pinjam')";
    
    $input = mysqli_query($koneksi, $query);

    if ($input) {
        mysqli_query($koneksi, "UPDATE tbl_buku SET stok = stok - 1 WHERE id_buku='$id_buku'");
        echo "success";
        exit;
    } else {
        // Ini akan menampilkan error database yang spesifik jika masih gagal
        echo "Database Error: " . mysqli_error($koneksi);
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Dashboard Siswa - Litera-Z</title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
    
    <style>
        .header-top { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; background: white; padding: 15px 25px; border-radius: 12px; box-shadow: 0 4px 6px rgba(0,0,0,0.05); }
        #clock { font-size: 1.1rem; font-weight: bold; color: #764ba2; background: #f3f0ff; padding: 5px 15px; border-radius: 30px; border: 1px solid #d1d1d1; min-width: 100px; text-align: center; }
        .welcome-box { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 30px; border-radius: 15px; margin-bottom: 25px; }
        .tab-container { background: white; padding: 20px; border-radius: 12px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); margin-bottom: 25px; }
        .btn-pinjam { background: #6c5ce7; color: white; border: none; padding: 8px 15px; border-radius: 20px; cursor: pointer; transition: 0.3s; font-weight: bold; }
        .btn-pinjam:hover { background: #a29bfe; transform: scale(1.05); }
        .status-badge { padding: 5px 10px; border-radius: 20px; font-size: 0.7rem; font-weight: bold; }
        .bg-pijam { background: #fff9db; color: #f08c00; }
        .bg-kembali { background: #ebfbee; color: #0ca678; }
    </style>
</head>
<body>
    <div class="dashboard-container">
        <aside class="sidebar">
            <div class="sidebar-header"><h2>Litera-Z</h2></div>
            <ul class="sidebar-menu">
                <li><a href="index.php" class="active">Dashboard</a></li>
                <li><a href="../logout.php">Logout</a></li>
            </ul>
        </aside>

        <main class="main-content">
            <div class="header-top">
                <div class="user-info">🏠 <b>Siswa:</b> <?php echo $nama_user; ?></div>
                <div id="clock">00:00:00</div>
            </div>

            <div class="welcome-box">
                <h1>Halo, <?php echo $nama_user; ?>! 👋</h1>
                <p>Silakan pilih buku dan tentukan tanggal pengembaliannya.</p>
            </div>

            <div class="tab-container">
                <h2 style="margin-bottom: 15px;">📚 Katalog Buku</h2>
                <table id="tabelBuku" class="display" style="width:100%">
                    <thead>
                        <tr>
                            <th>Judul Buku</th>
                            <th>Stok</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $buku = mysqli_query($koneksi, "SELECT * FROM tbl_buku");
                        while($b = mysqli_fetch_array($buku)){
                        ?>
                        <tr>
                            <td><b><?php echo $b['judul']; ?></b></td>
                            <td><?php echo $b['stok']; ?></td>
                            <td>
                                <?php if($b['stok'] > 0){ ?>
                                    <button onclick="pinjamBuku('<?php echo $b['id_buku']; ?>', '<?php echo $b['judul']; ?>')" class="btn-pinjam">Pinjam</button>
                                <?php } else { echo "<span style='color:red'>Habis</span>"; } ?>
                            </td>
                        </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>

            <div class="tab-container">
                <h2 style="margin-bottom: 15px;">⏳ Riwayat Pinjaman Anda</h2>
                <table id="tabelRiwayat" class="display" style="width:100%">
                    <thead>
                        <tr>
                            <th>Buku</th>
                            <th>Tgl Pinjam</th>
                            <th>Batas Kembali</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        // Memastikan query tidak error dengan JOIN yang benar
                        $riwayat = mysqli_query($koneksi, "SELECT tbl_transaksi.*, tbl_buku.judul 
                                                          FROM tbl_transaksi 
                                                          JOIN tbl_buku ON tbl_transaksi.id_buku = tbl_buku.id_buku 
                                                          WHERE tbl_transaksi.nis = '$nis_user' 
                                                          ORDER BY id_transaksi DESC");
                        if($riwayat){
                            while($r = mysqli_fetch_array($riwayat)){
                            ?>
                            <tr>
                                <td><?php echo $r['judul']; ?></td>
                                <td><?php echo date('d/m/Y', strtotime($r['tgl_pinjam'])); ?></td>
                                <td style="color:red; font-weight:bold;"><?php echo date('d/m/Y', strtotime($r['tgl_kembali'])); ?></td>
                                <td>
                                    <span class="status-badge <?php echo ($r['status']=='pinjam') ? 'bg-pijam' : 'bg-kembali'; ?>">
                                        <?php echo ($r['status']=='pinjam') ? 'Dipinjam' : 'Selesai'; ?>
                                    </span>
                                </td>
                            </tr>
                            <?php 
                            }
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </main>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <script>
        // PERBAIKAN JAM: Pastikan fungsi ini dipanggil
        function updateClock() {
            const now = new Date();
            const options = { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false };
            document.getElementById('clock').textContent = now.toLocaleTimeString('id-ID', options);
        }
        setInterval(updateClock, 1000);
        updateClock(); // Jalankan sekali saat load agar tidak menunggu 1 detik

        $(document).ready(function() {
            $('#tabelBuku').DataTable();
            $('#tabelRiwayat').DataTable();
        });

        function pinjamBuku(id, judul) {
            Swal.fire({
                title: 'Pinjam Buku?',
                html: `Buku: <b>${judul}</b><br><br>Pilih Tanggal Kembali:<br><input type="date" id="tgl_estimasi" class="swal2-input" min="<?php echo date('Y-m-d'); ?>">`,
                icon: 'question',
                showCancelButton: true,
                confirmButtonColor: '#6c5ce7',
                confirmButtonText: 'Konfirmasi',
                preConfirm: () => {
                    const tgl = document.getElementById('tgl_estimasi').value;
                    if (!tgl) { Swal.showValidationMessage('Tanggal wajib diisi!'); }
                    return tgl;
                }
            }).then((result) => {
                if (result.isConfirmed) {
                    $.ajax({
                        url: 'index.php',
                        type: 'POST',
                        data: { id_buku_pinjam: id, tgl_estimasi: result.value },
                        success: function(response) {
                            if(response.trim() == "success") {
                                Swal.fire({
                                    icon: 'success',
                                    title: 'Berhasil!',
                                    text: 'Buku berhasil dipinjam.',
                                    timer: 2000,
                                    showConfirmButton: false
                                }).then(() => location.reload());
                            } else {
                                Swal.fire('Gagal!', 'Error: ' + response, 'error');
                            }
                        },
                        error: function() {
                            Swal.fire('Error!', 'Gagal terhubung ke server.', 'error');
                        }
                    });
                }
            });
        }
    </script>
</body>
</html>