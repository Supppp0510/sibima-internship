<?php
$host = "localhost";
$user = "root";
$pass = "";
$db   = "db_perpustakaan"; // <--- Pastikan ejaannya SAMA PERSIS dengan phpMyAdmin

$koneksi = mysqli_connect($host, $user, $pass, $db);

if (!$koneksi) {
    die("Koneksi Gagal: " . mysqli_connect_error());
}
?>