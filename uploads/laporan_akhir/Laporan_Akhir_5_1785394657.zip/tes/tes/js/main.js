// Authentication & Session Management
const AUTH_KEY = 'digital_library_auth';
const USERNAME = 'admin';
const PASSWORD = '1234';
const PASSWORD_KEY = 'admin_password';

// Get current password from localStorage or use default
function getCurrentPassword() {
    return localStorage.getItem(PASSWORD_KEY) || PASSWORD; // Default: '1234'
}

// Check if user is logged in
function checkAuth() {
    const auth = localStorage.getItem(AUTH_KEY);
    if (!auth && !window.location.pathname.includes('index.php')) {
        window.location.href = 'index.php';
        return false;
    }
    return auth === 'true';
}

// Login function
function handleLogin(event) {
    event.preventDefault();
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    const errorDiv = document.getElementById('error-message');

    const currentPassword = getCurrentPassword();
    
    if (username === USERNAME && password === currentPassword) {
        localStorage.setItem(AUTH_KEY, 'true');
        window.location.href = 'dashboard.php';
    } else {
        errorDiv.textContent = 'Username atau password salah!';
        errorDiv.style.display = 'block';
    }
}

// Logout function
function handleLogout() {
    localStorage.removeItem(AUTH_KEY);
    window.location.href = 'index.php';
}

// Initialize auth check on page load
document.addEventListener('DOMContentLoaded', function() {
    // Add logout button if exists
    const logoutBtn = document.getElementById('logout-btn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', handleLogout);
    }

    // Set active navigation item
    const currentPage = window.location.pathname.split('/').pop() || 'index.php';
    const navLinks = document.querySelectorAll('.sidebar-menu a');
    navLinks.forEach(link => {
        const href = link.getAttribute('href');
        if (href === currentPage || (currentPage === '' && href === 'dashboard.php')) {
            link.classList.add('active');
        }
    });

    // Check auth for all pages except login
    if (currentPage !== 'index.php' && currentPage !== '') {
        checkAuth();
    }

    // Initialize login form
    const loginForm = document.getElementById('login-form');
    if (loginForm) {
        loginForm.addEventListener('submit', handleLogin);
    }
});

// Data Management - Books
let booksData = JSON.parse(localStorage.getItem('booksData')) || [
    { id: 1, title: 'Belajar JavaScript', author: 'John Doe', isbn: '978-1234567890', year: 2023, stock: 5 },
    { id: 2, title: 'Pengantar Web Design', author: 'Jane Smith', isbn: '978-0987654321', year: 2022, stock: 3 },
    { id: 3, title: 'Database Management', author: 'Bob Johnson', isbn: '978-1122334455', year: 2024, stock: 8 }
];

// Data Management - Members
let membersData = JSON.parse(localStorage.getItem('membersData')) || [
    { id: 1, name: 'Ahmad Fauzi', kelas: 'XII IPA 1', nis: '12345', email: 'ahmad@example.com' },
    { id: 2, name: 'Siti Nurhaliza', kelas: 'XI IPS 2', nis: '12346', email: 'siti@example.com' },
    { id: 3, name: 'Budi Santoso', kelas: 'X IPA 3', nis: '12347', email: 'budi@example.com' }
];

// Data Management - Classes
let classesData = JSON.parse(localStorage.getItem('classesData')) || [
    { id: 1, name: 'X IPA 1', level: 'X', major: 'IPA' },
    { id: 2, name: 'X IPA 2', level: 'X', major: 'IPA' },
    { id: 3, name: 'XI IPS 1', level: 'XI', major: 'IPS' },
    { id: 4, name: 'XII IPA 1', level: 'XII', major: 'IPA' }
];

// Data Management - Transactions
let transactionsData = JSON.parse(localStorage.getItem('transactionsData')) || [
    { id: 1, bookId: 1, memberId: 1, borrowDate: '2025-10-01', returnDate: null, status: 'borrowed' },
    { id: 2, bookId: 2, memberId: 2, borrowDate: '2025-10-15', returnDate: '2025-10-20', status: 'returned' },
    { id: 3, bookId: 3, memberId: 3, borrowDate: '2025-10-25', returnDate: null, status: 'borrowed' }
];

// Save data to localStorage
function saveData() {
    localStorage.setItem('booksData', JSON.stringify(booksData));
    localStorage.setItem('membersData', JSON.stringify(membersData));
    localStorage.setItem('classesData', JSON.stringify(classesData));
    localStorage.setItem('transactionsData', JSON.stringify(transactionsData));
}

// Books Functions
function renderBooks() {
    const tbody = document.getElementById('books-table-body');
    if (!tbody) return;

    tbody.innerHTML = '';
    booksData.forEach(book => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${book.id}</td>
            <td>${book.title}</td>
            <td>${book.author}</td>
            <td>${book.isbn}</td>
            <td>${book.year}</td>
            <td>${book.stock}</td>
            <td>
                <button class="btn btn-danger" onclick="deleteBook(${book.id})">Hapus</button>
            </td>
        `;
        tbody.appendChild(row);
    });
}

function addBook(event) {
    event.preventDefault();
    const title = document.getElementById('book-title').value;
    const author = document.getElementById('book-author').value;
    const isbn = document.getElementById('book-isbn').value;
    const year = parseInt(document.getElementById('book-year').value);
    const stock = parseInt(document.getElementById('book-stock').value);

    const newBook = {
        id: booksData.length > 0 ? Math.max(...booksData.map(b => b.id)) + 1 : 1,
        title,
        author,
        isbn,
        year,
        stock
    };

    booksData.push(newBook);
    saveData();
    renderBooks();
    document.getElementById('book-form').reset();
    alert('Buku berhasil ditambahkan!');
}

function deleteBook(id) {
    if (confirm('Apakah Anda yakin ingin menghapus buku ini?')) {
        booksData = booksData.filter(book => book.id !== id);
        saveData();
        renderBooks();
        alert('Buku berhasil dihapus!');
    }
}

// Members Functions
function renderMembers() {
    const tbody = document.getElementById('members-table-body');
    if (!tbody) return;

    tbody.innerHTML = '';
    membersData.forEach(member => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${member.id}</td>
            <td>${member.name}</td>
            <td>${member.kelas}</td>
            <td>${member.nis}</td>
            <td>${member.email}</td>
            <td>
                <button class="btn btn-danger" onclick="deleteMember(${member.id})">Hapus</button>
            </td>
        `;
        tbody.appendChild(row);
    });
}

function addMember(event) {
    event.preventDefault();
    const name = document.getElementById('member-name').value;
    const kelas = document.getElementById('member-kelas').value;
    const nis = document.getElementById('member-nis').value;
    const email = document.getElementById('member-email').value;

    const newMember = {
        id: membersData.length > 0 ? Math.max(...membersData.map(m => m.id)) + 1 : 1,
        name,
        kelas,
        nis,
        email
    };

    membersData.push(newMember);
    saveData();
    renderMembers();
    document.getElementById('member-form').reset();
    alert('Anggota berhasil ditambahkan!');
}

function deleteMember(id) {
    if (confirm('Apakah Anda yakin ingin menghapus anggota ini?')) {
        membersData = membersData.filter(member => member.id !== id);
        saveData();
        renderMembers();
        alert('Anggota berhasil dihapus!');
    }
}

// Classes Functions
function renderClasses() {
    const tbody = document.getElementById('classes-table-body');
    if (!tbody) return;

    tbody.innerHTML = '';
    classesData.forEach(cls => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${cls.id}</td>
            <td>${cls.name}</td>
            <td>${cls.level}</td>
            <td>${cls.major}</td>
        `;
        tbody.appendChild(row);
    });
}

// Transactions Functions
function renderTransactions() {
    const tbody = document.getElementById('transactions-table-body');
    if (!tbody) return;

    tbody.innerHTML = '';
    transactionsData.forEach(transaction => {
        const book = booksData.find(b => b.id === transaction.bookId);
        const member = membersData.find(m => m.id === transaction.memberId);
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${transaction.id}</td>
            <td>${book ? book.title : 'N/A'}</td>
            <td>${member ? member.name : 'N/A'}</td>
            <td>${transaction.borrowDate}</td>
            <td>${transaction.returnDate || '-'}</td>
            <td>
                <span style="padding: 0.25rem 0.75rem; border-radius: 3px; background-color: ${transaction.status === 'borrowed' ? '#e74c3c' : '#27ae60'}; color: white;">
                    ${transaction.status === 'borrowed' ? 'Dipinjam' : 'Dikembalikan'}
                </span>
            </td>
            <td>
                ${transaction.status === 'borrowed' ? `<button class="btn btn-success" onclick="returnBook(${transaction.id})">Kembalikan</button>` : '-'}
            </td>
        `;
        tbody.appendChild(row);
    });
}

function borrowBook(event) {
    event.preventDefault();
    const bookId = parseInt(document.getElementById('borrow-book').value);
    const memberId = parseInt(document.getElementById('borrow-member').value);
    const borrowDate = document.getElementById('borrow-date').value;

    const book = booksData.find(b => b.id === bookId);
    if (book && book.stock > 0) {
        const newTransaction = {
            id: transactionsData.length > 0 ? Math.max(...transactionsData.map(t => t.id)) + 1 : 1,
            bookId,
            memberId,
            borrowDate,
            returnDate: null,
            status: 'borrowed'
        };

        transactionsData.push(newTransaction);
        book.stock -= 1;
        saveData();
        renderTransactions();
        renderBooks();
        document.getElementById('borrow-form').reset();
        alert('Peminjaman berhasil!');
    } else {
        alert('Buku tidak tersedia atau stok habis!');
    }
}

function returnBook(transactionId) {
    if (confirm('Apakah Anda yakin ingin mengembalikan buku ini?')) {
        const transaction = transactionsData.find(t => t.id === transactionId);
        if (transaction) {
            transaction.returnDate = new Date().toISOString().split('T')[0];
            transaction.status = 'returned';
            const book = booksData.find(b => b.id === transaction.bookId);
            if (book) {
                book.stock += 1;
            }
            saveData();
            renderTransactions();
            renderBooks();
            alert('Buku berhasil dikembalikan!');
        }
    }
}

// Reports Functions
function renderReports() {
    const totalBooks = booksData.length;
    const totalMembers = membersData.length;
    const totalBorrowed = transactionsData.filter(t => t.status === 'borrowed').length;
    const totalReturned = transactionsData.filter(t => t.status === 'returned').length;

    const reportContent = document.getElementById('report-content');
    if (reportContent) {
        reportContent.innerHTML = `
            <div class="stats-grid">
                <div class="stat-card">
                    <h3>Total Buku</h3>
                    <div class="stat-value">${totalBooks}</div>
                </div>
                <div class="stat-card">
                    <h3>Total Anggota</h3>
                    <div class="stat-value">${totalMembers}</div>
                </div>
                <div class="stat-card">
                    <h3>Buku Dipinjam</h3>
                    <div class="stat-value">${totalBorrowed}</div>
                </div>
                <div class="stat-card">
                    <h3>Buku Dikembalikan</h3>
                    <div class="stat-value">${totalReturned}</div>
                </div>
            </div>
        `;
    }
}

// Dashboard Functions
function renderDashboard() {
    const totalBooks = booksData.length;
    const totalMembers = membersData.length;
    const totalTransactions = transactionsData.length;

    const booksCount = document.getElementById('books-count');
    const membersCount = document.getElementById('members-count');
    const transactionsCount = document.getElementById('transactions-count');

    if (booksCount) booksCount.textContent = totalBooks;
    if (membersCount) membersCount.textContent = totalMembers;
    if (transactionsCount) transactionsCount.textContent = totalTransactions;
}

// Settings Functions
const SETTINGS_KEY = 'library_settings';

// Load settings from localStorage
function loadSettings() {
    const settings = JSON.parse(localStorage.getItem(SETTINGS_KEY)) || {
        libraryName: 'Perpustakaan Digital',
        libraryAddress: '',
        libraryPhone: '',
        libraryEmail: '',
        maxBorrowDays: 7,
        maxBooksPerMember: 5,
        finePerDay: 1000,
        gracePeriod: 3
    };
    return settings;
}

// Save settings to localStorage
function saveSettings(settings) {
    localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
}

// Update password
function updatePassword(currentPassword, newPassword) {
    const storedPassword = getCurrentPassword();
    if (currentPassword !== storedPassword) {
        return { success: false, message: 'Password saat ini salah!' };
    }
    if (newPassword.length < 4) {
        return { success: false, message: 'Password baru minimal 4 karakter!' };
    }
    localStorage.setItem(PASSWORD_KEY, newPassword);
    return { success: true, message: 'Password berhasil diubah!' };
}

// Handle password form
function handlePasswordChange(event) {
    event.preventDefault();
    const currentPassword = document.getElementById('current-password').value;
    const newPassword = document.getElementById('new-password').value;
    const confirmPassword = document.getElementById('confirm-password').value;
    const messageDiv = document.getElementById('password-message');

    if (newPassword !== confirmPassword) {
        messageDiv.innerHTML = '<div class="alert alert-error">Password baru dan konfirmasi password tidak cocok!</div>';
        return;
    }

    const result = updatePassword(currentPassword, newPassword);
    if (result.success) {
        messageDiv.innerHTML = '<div class="alert" style="background-color: #d4edda; color: #155724; border: 1px solid #c3e6cb; padding: 0.75rem; border-radius: 5px;">' + result.message + '</div>';
        document.getElementById('password-form').reset();
    } else {
        messageDiv.innerHTML = '<div class="alert alert-error">' + result.message + '</div>';
    }
}

// Handle system settings form
function handleSystemSettings(event) {
    event.preventDefault();
    const settings = loadSettings();
    settings.libraryName = document.getElementById('library-name').value;
    settings.libraryAddress = document.getElementById('library-address').value;
    settings.libraryPhone = document.getElementById('library-phone').value;
    settings.libraryEmail = document.getElementById('library-email').value;
    
    saveSettings(settings);
    const messageDiv = document.getElementById('system-message');
    messageDiv.innerHTML = '<div class="alert" style="background-color: #d4edda; color: #155724; border: 1px solid #c3e6cb; padding: 0.75rem; border-radius: 5px;">Pengaturan sistem berhasil disimpan!</div>';
}

// Handle borrow settings form
function handleBorrowSettings(event) {
    event.preventDefault();
    const settings = loadSettings();
    settings.maxBorrowDays = parseInt(document.getElementById('max-borrow-days').value);
    settings.maxBooksPerMember = parseInt(document.getElementById('max-books-per-member').value);
    settings.finePerDay = parseInt(document.getElementById('fine-per-day').value);
    settings.gracePeriod = parseInt(document.getElementById('grace-period').value);
    
    saveSettings(settings);
    const messageDiv = document.getElementById('borrow-message');
    messageDiv.innerHTML = '<div class="alert" style="background-color: #d4edda; color: #155724; border: 1px solid #c3e6cb; padding: 0.75rem; border-radius: 5px;">Pengaturan peminjaman berhasil disimpan!</div>';
}

// Load settings to form
function loadSettingsToForm() {
    const settings = loadSettings();
    
    // Load system settings
    const libraryName = document.getElementById('library-name');
    const libraryAddress = document.getElementById('library-address');
    const libraryPhone = document.getElementById('library-phone');
    const libraryEmail = document.getElementById('library-email');
    
    if (libraryName) libraryName.value = settings.libraryName || '';
    if (libraryAddress) libraryAddress.value = settings.libraryAddress || '';
    if (libraryPhone) libraryPhone.value = settings.libraryPhone || '';
    if (libraryEmail) libraryEmail.value = settings.libraryEmail || '';
    
    // Load borrow settings
    const maxBorrowDays = document.getElementById('max-borrow-days');
    const maxBooksPerMember = document.getElementById('max-books-per-member');
    const finePerDay = document.getElementById('fine-per-day');
    const gracePeriod = document.getElementById('grace-period');
    
    if (maxBorrowDays) maxBorrowDays.value = settings.maxBorrowDays || 7;
    if (maxBooksPerMember) maxBooksPerMember.value = settings.maxBooksPerMember || 5;
    if (finePerDay) finePerDay.value = settings.finePerDay || 1000;
    if (gracePeriod) gracePeriod.value = settings.gracePeriod || 3;
}

// Backup data
function backupData() {
    const backup = {
        books: booksData,
        members: membersData,
        classes: classesData,
        transactions: transactionsData,
        settings: loadSettings(),
        backupDate: new Date().toISOString()
    };
    
    const dataStr = JSON.stringify(backup, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `library_backup_${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    
    const messageDiv = document.getElementById('backup-message');
    messageDiv.innerHTML = '<div class="alert" style="background-color: #d4edda; color: #155724; border: 1px solid #c3e6cb; padding: 0.75rem; border-radius: 5px;">Backup berhasil didownload!</div>';
}

// Restore data
function restoreData(file) {
    const reader = new FileReader();
    reader.onload = function(e) {
        try {
            const backup = JSON.parse(e.target.result);
            
            if (confirm('Restore akan mengganti semua data saat ini. Lanjutkan?')) {
                if (backup.books) booksData = backup.books;
                if (backup.members) membersData = backup.members;
                if (backup.classes) classesData = backup.classes;
                if (backup.transactions) transactionsData = backup.transactions;
                if (backup.settings) saveSettings(backup.settings);
                
                saveData();
                
                const messageDiv = document.getElementById('backup-message');
                messageDiv.innerHTML = '<div class="alert" style="background-color: #d4edda; color: #155724; border: 1px solid #c3e6cb; padding: 0.75rem; border-radius: 5px;">Data berhasil direstore! Halaman akan dimuat ulang...</div>';
                
                setTimeout(() => {
                    location.reload();
                }, 2000);
            }
        } catch (error) {
            const messageDiv = document.getElementById('backup-message');
            messageDiv.innerHTML = '<div class="alert alert-error">Error: File backup tidak valid!</div>';
        }
    };
    reader.readAsText(file);
}


// Initialize page-specific functions
document.addEventListener('DOMContentLoaded', function() {
    // Initialize books page
    if (document.getElementById('books-table-body')) {
        renderBooks();
        const bookForm = document.getElementById('book-form');
        if (bookForm) {
            bookForm.addEventListener('submit', addBook);
        }
    }

    // Initialize members page
    if (document.getElementById('members-table-body')) {
        renderMembers();
        const memberForm = document.getElementById('member-form');
        if (memberForm) {
            memberForm.addEventListener('submit', addMember);
        }
        // Populate kelas dropdown
        const kelasSelect = document.getElementById('member-kelas');
        if (kelasSelect) {
            classesData.forEach(cls => {
                const option = document.createElement('option');
                option.value = cls.name;
                option.textContent = cls.name;
                kelasSelect.appendChild(option);
            });
        }
    }

    // Initialize classes page
    if (document.getElementById('classes-table-body')) {
        renderClasses();
    }

    // Initialize transactions page
    if (document.getElementById('transactions-table-body')) {
        renderTransactions();
        const borrowForm = document.getElementById('borrow-form');
        if (borrowForm) {
            borrowForm.addEventListener('submit', borrowBook);
        }
        // Populate book and member dropdowns
        const bookSelect = document.getElementById('borrow-book');
        const memberSelect = document.getElementById('borrow-member');
        if (bookSelect) {
            booksData.forEach(book => {
                const option = document.createElement('option');
                option.value = book.id;
                option.textContent = `${book.title} (Stok: ${book.stock})`;
                bookSelect.appendChild(option);
            });
        }
        if (memberSelect) {
            membersData.forEach(member => {
                const option = document.createElement('option');
                option.value = member.id;
                option.textContent = `${member.name} - ${member.kelas}`;
                memberSelect.appendChild(option);
            });
        }
    }

    // Initialize reports page
    if (document.getElementById('report-content')) {
        renderReports();
    }

    // Initialize dashboard
    if (document.getElementById('books-count')) {
        renderDashboard();
    }

    // Initialize settings page
    if (document.getElementById('password-form')) {
        loadSettingsToForm();
        document.getElementById('password-form').addEventListener('submit', handlePasswordChange);
        document.getElementById('system-form').addEventListener('submit', handleSystemSettings);
        document.getElementById('borrow-settings-form').addEventListener('submit', handleBorrowSettings);
        
        // Backup button
        const backupBtn = document.getElementById('backup-btn');
        if (backupBtn) {
            backupBtn.addEventListener('click', backupData);
        }
        
        // Restore button
        const restoreBtn = document.getElementById('restore-btn');
        const restoreFile = document.getElementById('restore-file');
        if (restoreBtn && restoreFile) {
            restoreBtn.addEventListener('click', () => restoreFile.click());
            restoreFile.addEventListener('change', (e) => {
                if (e.target.files.length > 0) {
                    restoreData(e.target.files[0]);
                }
            });
        }
    }
});

