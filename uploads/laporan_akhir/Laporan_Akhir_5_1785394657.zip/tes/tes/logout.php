<?php
// FILE: logout.php
session_start(); // Mengaktifkan sesi agar bisa dihapus

// Menghapus semua data sesi
session_destroy();

// Mengarahkan kembali ke halaman login dengan pesan
header("location:login.php?pesan=logout");
exit();
?>