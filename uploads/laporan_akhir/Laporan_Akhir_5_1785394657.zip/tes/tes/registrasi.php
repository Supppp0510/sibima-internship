<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Registrasi Siswa Baru - Litera-Z</title>
    <link rel="stylesheet" href="css/style.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        body { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); height: 100vh; display: flex; align-items: center; justify-content: center; font-family: sans-serif; }
        .reg-box { background: white; padding: 40px; border-radius: 15px; box-shadow: 0 10px 25px rgba(0,0,0,0.2); width: 100%; max-width: 400px; }
        .reg-box h2 { text-align: center; color: #4a5568; margin-bottom: 20px; }
        .form-group { margin-bottom: 15px; }
        .form-group label { display: block; margin-bottom: 5px; color: #718096; }
        .form-control { width: 100%; padding: 10px; border: 1px solid #cbd5e0; border-radius: 8px; outline: none; }
        .btn-reg { width: 100%; padding: 12px; background: #6c5ce7; border: none; color: white; border-radius: 8px; font-weight: bold; cursor: pointer; transition: 0.3s; margin-top: 10px; }
        .btn-reg:hover { background: #a29bfe; }
        .link-login { display: block; text-align: center; margin-top: 15px; color: #667eea; text-decoration: none; font-size: 0.9rem; }
    </style>
</head>
<body>
    <div class="reg-box">
        <h2>Daftar Akun Siswa</h2>
        <form action="proses_registrasi.php" method="POST">
            <div class="form-group">
                <label>Nama Lengkap</label>
                <input type="text" name="nama_lengkap" class="form-control" placeholder="Masukkan nama asli" required>
            </div>
            <div class="form-group">
                <label>NIS (Username)</label>
                <input type="text" name="username" class="form-control" placeholder="Masukkan NIS untuk login" required>
            </div>
            <div class="form-group">
                <label>Password</label>
                <input type="password" name="password" class="form-control" placeholder="Buat password" required>
            </div>
            <button type="submit" class="btn-reg">Daftar Sekarang</button>
            <a href="index.php" class="link-login">Sudah punya akun? Login di sini</a>
        </form>
    </div>
</body>
</html>