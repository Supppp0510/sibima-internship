Notes / Next steps:
- Add Riverpod state management and offline DB (drift) layers.
- Implement auth mock & role guards.
- Implement sync queue & status icon per item.
- Use build_runner to generate Freezed *.g.dart and *.freezed.dart files.

Recommended packages:
- flutter_riverpod, drift, dio, flutter_secure_storage, connectivity_plus, go_router, printing

