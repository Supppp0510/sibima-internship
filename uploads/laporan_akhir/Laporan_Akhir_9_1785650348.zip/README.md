# e-Penilaian Santri - Flutter Template

Template scaffold for the e-Penilaian Santri project:
- Freezed models (santri, penilaian, kehadiran)
- Calculation utilities (akhlak conversion, tahfidz/subject/final score, attendance recap)
- Unit tests for core calculations

How to use:
1. Install Flutter (stable 3.x+) and set up environment.
2. From project root run:
   - `flutter pub get`
   - `flutter pub run build_runner build --delete-conflicting-outputs` (to generate freezed files)
3. Run tests:
   - `flutter test`

This template contains minimal, focused code for the domain logic. Expand features (offline DB, Riverpod, UI, sync) on top.

