import 'package:flutter_test/flutter_test.dart';
import 'package:e_penilaian_santri/core/utils/calculations.dart';

void main() {
  group('Akhlak conversion', () {
    test('max scores -> 100', () {
      final v = convertAkhlakTo100(disiplin: 4, adab: 4, kebersihan: 4, kerjasama: 4);
      expect(v, 100);
    });

    test('example s1 -> 94', () {
      final v = convertAkhlakTo100(disiplin: 4, adab: 4, kebersihan: 3, kerjasama: 4);
      expect(v, 94);
    });

    test('example s2 -> 69', () {
      final v = convertAkhlakTo100(disiplin: 3, adab: 3, kebersihan: 3, kerjasama: 2);
      expect(v, 69);
    });
  });

  group('Tahfidz calculation', () {
    test('s1 example -> 93', () {
      final v = calculateTahfidz(ayatSetor: 60, targetMingguan: 50, tajwid: 85);
      expect(v, 93);
    });

    test('s2 example -> 69', () {
      final v = calculateTahfidz(ayatSetor: 30, targetMingguan: 50, tajwid: 78);
      expect(v, 69);
    });
  });

  group('Mapel calculation', () {
    test('fiqh s1 -> 86', () {
      final v = calculateMapel(formatif: 80, sumatif: 90);
      expect(v, 86);
    });

    test('bahasa s2 -> 63', () {
      final v = calculateMapel(formatif: 60, sumatif: 65);
      expect(v, 63);
    });
  });

  group('Kehadiran recap', () {
    test('s1 -> 90', () {
      final v = calculateKehadiranScore(hadir: 18, sakit:1, izin:1, alpa:0);
      expect(v, 90);
    });

    test('s2 -> 70', () {
      final v = calculateKehadiranScore(hadir: 14, sakit:2, izin:1, alpa:3);
      expect(v, 70);
    });
  });

  group('Final & predikat', () {
    test('s1 example final -> 89 and A', () {
      final tahfidz = calculateTahfidz(ayatSetor:60, targetMingguan:50, tajwid:85);
      final fiqh = calculateMapel(formatif:80, sumatif:90);
      final bahasa = calculateMapel(formatif:75, sumatif:80);
      final akhlak = convertAkhlakTo100(disiplin:4, adab:4, kebersihan:3, kerjasama:4);
      final hadir = calculateKehadiranScore(hadir:18, sakit:1, izin:1, alpa:0);
      final finalScore = calculateFinalScore(
        tahfidz: tahfidz, fiqh: fiqh, bahasaArab: bahasa, akhlak: akhlak, kehadiran: hadir);
      expect(finalScore, 89);
      expect(predikatFromScore(finalScore), 'A');
    });

    test('s2 example final -> 69 and C', () {
      final tahfidz = calculateTahfidz(ayatSetor:30, targetMingguan:50, tajwid:78);
      final fiqh = calculateMapel(formatif:70, sumatif:75);
      final bahasa = calculateMapel(formatif:60, sumatif:65);
      final akhlak = convertAkhlakTo100(disiplin:3, adab:3, kebersihan:3, kerjasama:2);
      final hadir = calculateKehadiranScore(hadir:14, sakit:2, izin:1, alpa:3);
      final finalScore = calculateFinalScore(
        tahfidz: tahfidz, fiqh: fiqh, bahasaArab: bahasa, akhlak: akhlak, kehadiran: hadir);
      expect(finalScore, 69);
      expect(predikatFromScore(finalScore), 'C');
    });
  });
}
