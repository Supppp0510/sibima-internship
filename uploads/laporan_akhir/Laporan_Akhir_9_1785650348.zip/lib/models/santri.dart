import 'package:freezed_annotation/freezed_annotation.dart';
part 'santri.freezed.dart';
part 'santri.g.dart';

@freezed
class Santri with _$Santri {
  const factory Santri({
    required String id,
    required String nis,
    required String nama,
    required String kamar,
    required int angkatan,
  }) = _Santri;

  factory Santri.fromJson(Map<String, dynamic> json) => _$SantriFromJson(json);
}
