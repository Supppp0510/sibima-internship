import 'package:freezed_annotation/freezed_annotation.dart';
part 'penilaian_mapel.freezed.dart';
part 'penilaian_mapel.g.dart';

@freezed
class PenilaianMapel with _$PenilaianMapel {
  const factory PenilaianMapel({
    required String id,
    required String santriId,
    required String mapel, // "Fiqh" | "Bahasa Arab"
    required int formatif, // 0-100
    required int sumatif, // 0-100
  }) = _PenilaianMapel;

  factory PenilaianMapel.fromJson(Map<String, dynamic> json) => _$PenilaianMapelFromJson(json);
}
