import 'package:freezed_annotation/freezed_annotation.dart';
part 'penilaian_akhlak.freezed.dart';
part 'penilaian_akhlak.g.dart';

@freezed
class PenilaianAkhlak with _$PenilaianAkhlak {
  const factory PenilaianAkhlak({
    required String id,
    required String santriId,
    required int disiplin, // 1-4
    required int adab, // 1-4
    required int kebersihan, // 1-4
    required int kerjasama, // 1-4
    String? catatan,
  }) = _PenilaianAkhlak;

  factory PenilaianAkhlak.fromJson(Map<String, dynamic> json) => _$PenilaianAkhlakFromJson(json);
}
