import 'package:freezed_annotation/freezed_annotation.dart';
part 'penilaian_tahfidz.freezed.dart';
part 'penilaian_tahfidz.g.dart';

@freezed
class PenilaianTahfidz with _$PenilaianTahfidz {
  const factory PenilaianTahfidz({
    required String id,
    required String santriId,
    required DateTime minggu,
    required String surah,
    required int ayatSetor,
    required int targetMingguan,
    required int tajwid, // 0-100
  }) = _PenilaianTahfidz;

  factory PenilaianTahfidz.fromJson(Map<String, dynamic> json) => _$PenilaianTahfidzFromJson(json);
}
