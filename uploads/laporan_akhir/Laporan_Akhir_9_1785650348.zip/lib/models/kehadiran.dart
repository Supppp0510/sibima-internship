import 'package:freezed_annotation/freezed_annotation.dart';
part 'kehadiran.freezed.dart';
part 'kehadiran.g.dart';

@freezed
class Kehadiran with _$Kehadiran {
  const factory Kehadiran({
    required String id,
    required String santriId,
    required DateTime tanggal,
    required String status, // "H","S","I","A"
  }) = _Kehadiran;

  factory Kehadiran.fromJson(Map<String, dynamic> json) => _$KehadiranFromJson(json);
}
