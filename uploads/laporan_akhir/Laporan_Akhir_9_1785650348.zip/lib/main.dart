import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'e-Penilaian Santri (Template)',
      home: Scaffold(
        appBar: AppBar(title: const Text('e-Penilaian Santri - Template')),
        body: const Center(child: Text('This is a logic/template-only starter.')),
      ),
    );
  }
}
