// Pure Dart calculation utilities for unit testing.
//
// Rules implemented according to project spec.

int convertAkhlakTo100({
  required int disiplin,
  required int adab,
  required int kebersihan,
  required int kerjasama,
}) {
  final avg = (disiplin + adab + kebersihan + kerjasama) / 4.0;
  final value = (avg / 4.0) * 100.0;
  return value.round();
}

int calculateTahfidz({
  required int ayatSetor,
  required int targetMingguan,
  required int tajwid, // 0-100
}) {
  final capaian = targetMingguan == 0 ? 0.0 : (ayatSetor / targetMingguan) * 100.0;
  final capaianClamped = capaian > 100.0 ? 100.0 : capaian;
  final tahfidz = 0.5 * capaianClamped + 0.5 * tajwid;
  return tahfidz.round();
}

int calculateMapel({
  required int formatif,
  required int sumatif,
}) {
  final mapel = 0.4 * formatif + 0.6 * sumatif;
  return mapel.round();
}

int calculateKehadiranScore({
  required int hadir,
  required int sakit,
  required int izin,
  required int alpa,
}) {
  final total = hadir + sakit + izin + alpa;
  if (total == 0) return 0;
  final hadirPercent = (hadir / total) * 100.0;
  return hadirPercent.round();
}

int calculateFinalScore({
  required int tahfidz,
  required int fiqh,
  required int bahasaArab,
  required int akhlak,
  required int kehadiran,
  Map<String, double>? bobot,
}) {
  final b = bobot ?? {
    'tahfidz': 0.30,
    'fiqh': 0.20,
    'bahasaArab': 0.20,
    'akhlak': 0.20,
    'kehadiran': 0.10,
  };
  final finalScore = b['tahfidz']! * tahfidz +
      b['fiqh']! * fiqh +
      b['bahasaArab']! * bahasaArab +
      b['akhlak']! * akhlak +
      b['kehadiran']! * kehadiran;
  return finalScore.round();
}

String predikatFromScore(int score) {
  if (score >= 85) return 'A';
  if (score >= 75) return 'B';
  if (score >= 65) return 'C';
  return 'D';
}
